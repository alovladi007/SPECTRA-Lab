"""
API service for diffusion-sim.
"""

from .service import app

__all__ = ['app']
