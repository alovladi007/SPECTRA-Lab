# Session 7: Optical I - Complete Documentation
## UV-Vis-NIR and FTIR Spectroscopy Platform

**Version:** 1.0.0  
**Date:** October 24, 2025  
**Status:** Production Ready

---

## Table of Contents

1. [Overview](#overview)
2. [Theory & Physics](#theory--physics)
3. [System Architecture](#system-architecture)
4. [Installation Guide](#installation-guide)
5. [User Manual](#user-manual)
6. [API Reference](#api-reference)
7. [Standard Operating Procedures](#standard-operating-procedures)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Maintenance & Calibration](#maintenance--calibration)
10. [Safety Guidelines](#safety-guidelines)

---

## Overview

The Session 7 Optical I module provides comprehensive UV-Vis-NIR and FTIR spectroscopy capabilities for semiconductor characterization. This platform enables:

- **UV-Vis-NIR Spectroscopy** (200-3300 nm)
  - Absorption, transmission, and reflectance measurements
  - Band gap determination for semiconductors
  - Thin film thickness from interference patterns
  - Real-time spectral analysis

- **FTIR Spectroscopy** (400-4000 cm⁻¹)
  - Molecular vibration analysis
  - Functional group identification
  - Material composition analysis
  - Contamination detection

### Key Features

✅ **Automated Measurements** - Batch processing with queue management  
✅ **Advanced Analysis** - Band gap extraction, peak fitting, baseline correction  
✅ **Spectral Libraries** - Material identification and matching  
✅ **Quality Control** - Real-time S/N monitoring and validation  
✅ **Data Export** - Multiple formats (CSV, JCAMP-DX, HDF5)  
✅ **Compliance** - 21 CFR Part 11, ISO 17025 ready

---

## Theory & Physics

### UV-Vis-NIR Spectroscopy Fundamentals

#### Beer-Lambert Law

The fundamental relationship governing optical absorption:

```
A = εcl = -log₁₀(T)
```

Where:
- **A** = Absorbance (dimensionless)
- **ε** = Molar absorptivity (L mol⁻¹ cm⁻¹)
- **c** = Concentration (mol/L)
- **l** = Path length (cm)
- **T** = Transmittance (I/I₀)

#### Band Gap Determination

For semiconductors, the optical band gap can be determined using the Tauc method:

```
(αhν)ⁿ = B(hν - Eₘ)
```

Where:
- **α** = Absorption coefficient (cm⁻¹)
- **h** = Planck's constant (6.626×10⁻³⁴ J·s)
- **ν** = Frequency (Hz)
- **n** = Transition type exponent
  - n = 2 for direct allowed transitions
  - n = 1/2 for indirect allowed transitions
  - n = 2/3 for direct forbidden transitions
  - n = 1/3 for indirect forbidden transitions
- **B** = Constant
- **Eₘ** = Optical band gap (eV)

#### Thin Film Interference

For thin films, interference fringes appear due to multiple reflections:

```
2nt cos(θ) = mλ
```

Film thickness can be calculated from fringe spacing:

```
d = λ₁λ₂ / (2n|λ₂ - λ₁|)
```

### FTIR Spectroscopy Fundamentals

#### Fourier Transform

FTIR converts interferogram to spectrum using Fourier transform:

```
I(δ) = ∫ B(ν)cos(2πνδ)dν
B(ν) = ∫ I(δ)cos(2πνδ)dδ
```

Where:
- **I(δ)** = Interferogram intensity
- **B(ν)** = Spectral intensity
- **ν** = Wavenumber (cm⁻¹)
- **δ** = Optical path difference

#### Molecular Vibrations

Vibrational frequencies depend on:
- Bond strength (force constant k)
- Reduced mass (μ)

```
ν = (1/2πc) √(k/μ)
```

Common functional group frequencies:

| Functional Group | Wavenumber (cm⁻¹) | Intensity |
|-----------------|-------------------|-----------|
| O-H (alcohol) | 3200-3600 | Strong, broad |
| N-H (amine) | 3300-3500 | Medium |
| C-H (alkane) | 2850-3000 | Strong |
| C≡N (nitrile) | 2210-2260 | Medium |
| C=O (carbonyl) | 1670-1780 | Strong |
| C=C (aromatic) | 1450-1600 | Variable |
| Si-O | 1000-1100 | Strong |

---

## System Architecture

### Component Overview

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface Layer                   │
│  ┌─────────────────┐        ┌──────────────────┐       │
│  │  UV-Vis-NIR UI  │        │     FTIR UI      │       │
│  └────────┬────────┘        └────────┬─────────┘       │
└───────────┼───────────────────────────┼─────────────────┘
            │                           │
┌───────────▼───────────────────────────▼─────────────────┐
│                     API Gateway                          │
│         FastAPI + WebSocket + Authentication             │
└───────────┬─────────────────────────────────────────────┘
            │
┌───────────▼─────────────────────────────────────────────┐
│                  Analysis Engine Layer                   │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │
│  │  UV-Vis-NIR  │  │     FTIR     │  │   Spectral  │  │
│  │   Analyzer   │  │   Analyzer   │  │   Library   │  │
│  └──────────────┘  └──────────────┘  └─────────────┘  │
└─────────────────────────────────────────────────────────┘
            │
┌───────────▼─────────────────────────────────────────────┐
│                 Instrument Driver Layer                  │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │
│  │ PerkinElmer  │  │    Agilent   │  │    Bruker   │  │
│  │    Lambda    │  │     Cary     │  │    Vertex   │  │
│  └──────────────┘  └──────────────┘  └─────────────┘  │
└─────────────────────────────────────────────────────────┘
            │
┌───────────▼─────────────────────────────────────────────┐
│                    Data Storage Layer                    │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │
│  │  PostgreSQL  │  │     Redis    │  │    MinIO    │  │
│  │   (Metadata) │  │    (Cache)   │  │   (Spectra) │  │
│  └──────────────┘  └──────────────┘  └─────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Acquisition Flow**
   ```
   User Request → API → Instrument Driver → Hardware
        ↓                                      ↓
   UI Update ← WebSocket ← Progress ← Raw Data
   ```

2. **Analysis Flow**
   ```
   Raw Spectrum → Baseline Correction → Peak Detection
        ↓              ↓                    ↓
   Band Gap ← Tauc Analysis        Functional Groups
   ```

3. **Storage Flow**
   ```
   Raw Data → Compression → MinIO (S3)
        ↓                      ↓
   Metadata → PostgreSQL → Index
   ```

---

## Installation Guide

### Prerequisites

- **Operating System:** Ubuntu 20.04+ or CentOS 8+
- **Docker:** Version 24.0+
- **Docker Compose:** Version 2.20+
- **Python:** 3.9+
- **Node.js:** 18+
- **Memory:** Minimum 8GB RAM
- **Storage:** Minimum 50GB available

### Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/semiconductor-lab/platform.git
   cd platform/session7-optical
   ```

2. **Run deployment script**
   ```bash
   chmod +x deploy_session7.sh
   ./deploy_session7.sh staging
   ```

3. **Access the platform**
   - Frontend: http://localhost:3007
   - API Docs: http://localhost:8007/docs
   - MinIO: http://localhost:9001

### Manual Installation

#### Backend Setup

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt

# Setup database
psql -U postgres -c "CREATE DATABASE semiconductor_lab;"
psql -U postgres -d semiconductor_lab < migrations/session7_optical.sql

# Start backend
uvicorn backend.main:app --reload --port 8007
```

#### Frontend Setup

```bash
# Install dependencies
cd frontend
npm install

# Build application
npm run build

# Start frontend
npm start
```

#### Docker Setup

```bash
# Build images
docker build -t optical-backend:1.0.0 ./backend
docker build -t optical-frontend:1.0.0 ./frontend

# Start services
docker-compose -f docker-compose.session7.yml up -d
```

---

## User Manual

### UV-Vis-NIR Measurements

#### Basic Measurement

1. **Sample Preparation**
   - Clean cuvettes with appropriate solvent
   - For solids, ensure flat, clean surface
   - For thin films, mount perpendicular to beam

2. **Instrument Setup**
   - Select wavelength range (typically 200-1100 nm for Si)
   - Choose appropriate scan speed
   - Set slit width (2 nm standard)
   - Configure integration time

3. **Baseline Acquisition**
   - Insert reference (blank cuvette or substrate)
   - Click "Acquire Baseline"
   - Wait for completion

4. **Sample Measurement**
   - Insert sample
   - Click "Start Acquisition"
   - Monitor real-time display
   - Save results when complete

#### Band Gap Analysis

1. **Enable Band Gap Calculation**
   - Toggle "Calculate Band Gap" in analysis options
   - Select transition type:
     - Direct allowed (GaAs, CdTe)
     - Indirect allowed (Si, Ge)

2. **Tauc Plot Generation**
   - System automatically generates Tauc plot
   - Adjust fitting range if needed
   - Review R² value (should be >0.99)

3. **Results Interpretation**
   - Band gap energy in eV and nm
   - Compare with literature values
   - Export Tauc plot for reports

#### Thin Film Analysis

1. **Enable Interference Analysis**
   - Toggle "Analyze Interference"
   - Input refractive index of film

2. **Fringe Detection**
   - System identifies maxima/minima
   - Calculates thickness from fringe spacing
   - Reports average and standard deviation

### FTIR Measurements

#### Sample Preparation Methods

**Transmission Mode**
- **KBr Pellet:** Mix 1-2 mg sample with 100 mg KBr
- **Liquid Cell:** Use appropriate window material
- **Thin Film:** Mount on IR-transparent substrate

**ATR Mode**
- Place sample on crystal
- Apply consistent pressure
- Ensure good contact

#### Measurement Procedure

1. **Background Acquisition**
   - Purge sample chamber with N₂
   - Wait for stability (CO₂, H₂O lines minimal)
   - Acquire background (typically 32 scans)

2. **Sample Measurement**
   - Insert prepared sample
   - Select resolution (4 cm⁻¹ standard)
   - Choose number of scans
   - Start acquisition

3. **Data Processing**
   - Apply baseline correction
   - Convert to absorbance if needed
   - Identify peaks
   - Compare with library

#### Functional Group Identification

1. **Automatic Peak Detection**
   - System identifies major peaks
   - Suggests functional groups
   - Provides confidence scores

2. **Manual Assignment**
   - Click on peak to select
   - Enter assignment
   - Save to database

3. **Library Matching**
   - Click "Search Library"
   - Review matches
   - Verify with reference spectra

---

## API Reference

### Authentication

All API endpoints require JWT authentication:

```http
Authorization: Bearer <token>
```

### UV-Vis-NIR Endpoints

#### Start Measurement

```http
POST /api/optical/uv-vis-nir/measure
```

**Request Body:**
```json
{
  "sample_id": "uuid",
  "wavelength_range": [200, 1100],
  "scan_speed": 300,
  "slit_width": 2.0,
  "integration_time": 0.1,
  "average_scans": 3,
  "mode": "transmission"
}
```

**Response:**
```json
{
  "measurement_id": "uuid",
  "status": "acquiring",
  "progress": 0,
  "estimated_time": 180
}
```

#### Get Results

```http
GET /api/optical/uv-vis-nir/results/{measurement_id}
```

**Response:**
```json
{
  "measurement_id": "uuid",
  "spectrum": {
    "wavelength": [200, 201, ...],
    "intensity": [0.95, 0.94, ...],
    "baseline": [0.01, 0.01, ...],
    "corrected": [0.94, 0.93, ...]
  },
  "peaks": [
    {
      "wavelength": 450.5,
      "intensity": 0.65,
      "prominence": 0.25,
      "width": 15.2
    }
  ],
  "band_gap": {
    "value_ev": 1.12,
    "value_nm": 1107,
    "type": "indirect_allowed",
    "r_squared": 0.998
  },
  "quality_metrics": {
    "signal_to_noise": 1250,
    "saturation": false
  }
}
```

#### Analyze Spectrum

```http
POST /api/optical/uv-vis-nir/analyze
```

**Request Body:**
```json
{
  "spectrum_data": {
    "wavelength": [...],
    "intensity": [...]
  },
  "baseline_correction": true,
  "baseline_method": "als",
  "detect_peaks": true,
  "calculate_band_gap": true,
  "band_gap_type": "direct_allowed",
  "analyze_interference": false
}
```

### FTIR Endpoints

#### Start FTIR Measurement

```http
POST /api/optical/ftir/measure
```

**Request Body:**
```json
{
  "sample_id": "uuid",
  "wavenumber_range": [400, 4000],
  "resolution": 4,
  "number_of_scans": 32,
  "apodization": "happ-genzel",
  "detector": "DTGS",
  "beam_splitter": "KBr"
}
```

#### Identify Functional Groups

```http
POST /api/optical/ftir/identify-groups
```

**Request Body:**
```json
{
  "peaks": [
    {"wavenumber": 1715, "intensity": 0.8},
    {"wavenumber": 2950, "intensity": 0.6}
  ]
}
```

**Response:**
```json
{
  "functional_groups": [
    {
      "wavenumber": 1715,
      "assignments": ["C=O stretch (carbonyl)"],
      "confidence": 0.95
    },
    {
      "wavenumber": 2950,
      "assignments": ["C-H stretch (alkane)"],
      "confidence": 0.92
    }
  ]
}
```

#### Search Spectral Library

```http
POST /api/optical/spectra/library/search
```

**Request Body:**
```json
{
  "spectrum": {
    "wavenumber": [...],
    "intensity": [...]
  },
  "material_type": "polymer",
  "correlation_threshold": 0.9
}
```

### WebSocket Events

Connect to receive real-time updates:

```javascript
const ws = new WebSocket('ws://localhost:8007/ws');

ws.on('message', (data) => {
  const event = JSON.parse(data);
  switch(event.type) {
    case 'acquisition_progress':
      console.log(`Progress: ${event.progress}%`);
      break;
    case 'spectrum_update':
      updateChart(event.data);
      break;
    case 'analysis_complete':
      showResults(event.results);
      break;
  }
});
```

---

## Standard Operating Procedures

### SOP-OPT-001: UV-Vis-NIR Daily Calibration

**Purpose:** Ensure wavelength and photometric accuracy

**Procedure:**

1. **Wavelength Calibration**
   - Insert holmium oxide filter
   - Run wavelength scan 200-700 nm
   - Verify peaks at:
     - 279.3 ± 0.5 nm
     - 360.8 ± 0.5 nm
     - 453.4 ± 0.5 nm
     - 536.4 ± 0.5 nm
     - 637.5 ± 0.5 nm

2. **Photometric Calibration**
   - Insert neutral density filters
   - Measure at 546 nm
   - Verify:
     - 10% T filter: 10.0 ± 0.5%
     - 30% T filter: 30.0 ± 0.5%

3. **Baseline Flatness**
   - Run baseline with air
   - Verify <0.002 Abs variation

4. **Documentation**
   - Log results in system
   - Flag for service if out of spec

### SOP-OPT-002: FTIR Instrument Verification

**Purpose:** Verify FTIR performance

**Procedure:**

1. **Energy Check**
   - Remove sample
   - Run single-beam spectrum
   - Verify centerburst >1000 counts

2. **Resolution Check**
   - Insert polystyrene film
   - Acquire at 2 cm⁻¹ resolution
   - Verify peak separation at 2850/2870 cm⁻¹

3. **Wavenumber Calibration**
   - Measure polystyrene peaks
   - Verify:
     - 3027.1 ± 1 cm⁻¹
     - 2849.7 ± 1 cm⁻¹
     - 1601.4 ± 1 cm⁻¹
     - 1028.0 ± 1 cm⁻¹

4. **S/N Ratio**
   - 100% line at 2000-2100 cm⁻¹
   - Calculate peak-to-peak noise
   - Verify S/N >10,000:1

### SOP-OPT-003: Band Gap Measurement Protocol

**Purpose:** Standardized band gap determination

**Procedure:**

1. **Sample Requirements**
   - Thickness: 200-500 μm (bulk)
   - Surface: Polished, clean
   - Size: >10×10 mm

2. **Measurement Setup**
   - Range: 200 nm to 100 nm beyond expected edge
   - Speed: Slow (60 nm/min)
   - Slit: 1 nm
   - Baseline: Appropriate substrate

3. **Data Analysis**
   - Convert T to absorption coefficient
   - Generate Tauc plot
   - Select linear region (R² >0.99)
   - Extrapolate to x-intercept

4. **Validation**
   - Repeat 3 times
   - Report mean ± std dev
   - Compare with literature

---

## Troubleshooting Guide

### UV-Vis-NIR Issues

#### High Noise Level

**Symptoms:** Noisy spectrum, poor S/N ratio

**Causes & Solutions:**
1. **Lamp aging**
   - Check lamp hours
   - Replace if >2000 hours
   
2. **Slit too narrow**
   - Increase slit width
   - Balance resolution vs. signal

3. **Integration time too short**
   - Increase integration time
   - Use signal averaging

#### Baseline Drift

**Symptoms:** Sloping or curved baseline

**Causes & Solutions:**
1. **Temperature fluctuation**
   - Allow 30 min warm-up
   - Check room temperature stability

2. **Lamp instability**
   - Check lamp alignment
   - Clean lamp housing

3. **Detector issue**
   - Run detector diagnostics
   - Contact service if needed

### FTIR Issues

#### No Centerburst

**Symptoms:** No signal, flat line

**Causes & Solutions:**
1. **Laser failure**
   - Check laser indicator
   - Replace if necessary

2. **Mirror alignment**
   - Run alignment procedure
   - Check for obstructions

3. **Detector issue**
   - Check liquid N₂ level (MCT)
   - Verify detector voltage

#### Poor Resolution

**Symptoms:** Peaks not resolved

**Causes & Solutions:**
1. **Moisture/CO₂**
   - Increase purge flow
   - Check desiccant

2. **Apodization**
   - Try different function
   - Adjust parameters

3. **Mechanical issue**
   - Check mirror velocity
   - Service required

#### Spectral Artifacts

**Symptoms:** Unexpected peaks, distortions

**Causes & Solutions:**
1. **Sample too thick**
   - Dilute sample
   - Use thinner pellet

2. **Water vapor**
   - Improve purging
   - Subtract water spectrum

3. **Fringes**
   - Check for parallel surfaces
   - Wedge sample slightly

---

## Maintenance & Calibration

### Daily Maintenance

- **UV-Vis-NIR**
  - Clean sample compartment
  - Check cuvette cleanliness
  - Verify lamp hours

- **FTIR**
  - Check purge gas flow
  - Clean crystal (ATR)
  - Verify desiccant color

### Weekly Maintenance

- **UV-Vis-NIR**
  - Run performance check
  - Clean optical surfaces
  - Check wavelength accuracy

- **FTIR**
  - Run instrument test
  - Check laser power
  - Clean beamsplitter compartment

### Monthly Maintenance

- **UV-Vis-NIR**
  - Full wavelength calibration
  - Photometric linearity check
  - Update calibration certificate

- **FTIR**
  - Full system diagnostic
  - Clean all optics
  - Replace desiccant

### Annual Maintenance

- **Both Systems**
  - Professional service
  - Replace consumables
  - Full recertification
  - Update SOPs

### Calibration Standards

**UV-Vis-NIR Standards:**
- Holmium oxide (wavelength)
- Neutral density filters (photometric)
- NIST SRM 930e (transmittance)
- Stray light filters

**FTIR Standards:**
- Polystyrene film (wavenumber)
- NIST SRM 1921b (transmittance)
- Gas cells (resolution)

---

## Safety Guidelines

### UV-Vis-NIR Safety

#### UV Radiation Hazards

⚠️ **WARNING:** UV sources can cause eye and skin damage

**Protection Measures:**
- Never look directly at UV source
- Use UV-blocking safety glasses
- Keep sample compartment closed during operation
- Use UV-opaque shields

#### Chemical Safety

**Solvent Handling:**
- Use fume hood for volatile solvents
- Wear appropriate PPE
- Dispose in proper waste containers
- Check chemical compatibility

### FTIR Safety

#### Laser Safety

⚠️ **Class 1 Laser Product**

**Safety Measures:**
- Do not defeat interlocks
- Keep covers in place
- No user-serviceable parts

#### Cryogenic Safety (MCT Detector)

⚠️ **Liquid Nitrogen Hazards**

**Protection Measures:**
- Use insulated gloves
- Use proper dewar
- Ensure adequate ventilation
- Never seal container

#### Hygroscopic Windows

**KBr/NaCl Handling:**
- Store in desiccator
- Handle with gloves
- Clean with dry solvents only
- Replace if cloudy

### Emergency Procedures

#### Chemical Spill
1. Alert others in area
2. Contain spill if safe
3. Use appropriate spill kit
4. Notify supervisor
5. Complete incident report

#### UV Exposure
1. Remove from exposure
2. Flush affected area
3. Seek medical attention
4. Document incident

#### Equipment Failure
1. Stop operation immediately
2. Tag equipment "Out of Service"
3. Notify technician
4. Log in maintenance system

---

## Performance Specifications

### UV-Vis-NIR Specifications

| Parameter | Specification |
|-----------|--------------|
| Wavelength Range | 190-3300 nm |
| Wavelength Accuracy | ±0.3 nm (UV-Vis), ±1 nm (NIR) |
| Wavelength Reproducibility | ±0.1 nm |
| Spectral Bandwidth | 0.05-5 nm (UV-Vis), 0.2-20 nm (NIR) |
| Photometric Range | -4 to 4 Abs |
| Photometric Accuracy | ±0.003 Abs (at 1 Abs) |
| Photometric Noise | <0.00005 Abs (500 nm) |
| Baseline Flatness | ±0.001 Abs |
| Scan Speed | 1-3000 nm/min |
| Stray Light | <0.00008% T (220 nm, NaI) |

### FTIR Specifications

| Parameter | Specification |
|-----------|--------------|
| Wavenumber Range | 350-7800 cm⁻¹ |
| Resolution | 0.4 cm⁻¹ |
| Wavenumber Accuracy | ±0.01 cm⁻¹ |
| Signal-to-Noise | >45,000:1 (peak-to-peak, 1 min) |
| Scan Speed | 10 spectra/second at 16 cm⁻¹ |
| Beamsplitters | KBr, CaF₂, Mylar |
| Detectors | DTGS, MCT |
| Purge | Automated, N₂ or dry air |

---

## Validation Protocols

### IQ/OQ/PQ Procedures

#### Installation Qualification (IQ)
- Verify delivery completeness
- Check environmental conditions
- Confirm utility connections
- Document serial numbers
- Verify software installation

#### Operational Qualification (OQ)
- Wavelength accuracy test
- Photometric accuracy test
- Resolution verification
- Noise level measurement
- Baseline stability test

#### Performance Qualification (PQ)
- Method-specific testing
- Reference material analysis
- Precision/accuracy study
- Robustness testing
- System suitability

### 21 CFR Part 11 Compliance

✅ **Electronic Records**
- Secure, time-stamped storage
- Audit trail for all changes
- Backup and recovery procedures
- Data integrity checks

✅ **Electronic Signatures**
- User authentication
- Signature manifestation
- Signature linking to records
- Non-repudiation

✅ **Access Controls**
- Role-based permissions
- Password policies
- Session management
- Authority checks

---

## Appendix A: Common Materials Reference

### Semiconductor Band Gaps

| Material | Type | Eg (eV) @ 300K | λg (nm) |
|----------|------|----------------|---------|
| Si | Indirect | 1.12 | 1107 |
| Ge | Indirect | 0.66 | 1879 |
| GaAs | Direct | 1.42 | 873 |
| GaN | Direct | 3.4 | 365 |
| InP | Direct | 1.34 | 925 |
| SiC (4H) | Indirect | 3.26 | 380 |
| AlN | Direct | 6.2 | 200 |

### Common FTIR Peaks

| Functional Group | Wavenumber (cm⁻¹) | Notes |
|-----------------|-------------------|-------|
| Si-O | 1000-1100 | Strong, SiO₂ |
| Si-H | 2000-2250 | Multiple peaks |
| Si-N | 830-890 | Si₃N₄ |
| C-F | 1000-1400 | Fluoropolymers |
| P=O | 1250-1350 | Phosphorus compounds |
| As-O | 800-900 | Arsenic oxides |

---

## Appendix B: Conversion Factors

### Energy-Wavelength Conversions

```
E(eV) = 1239.84 / λ(nm)
E(J) = hc / λ = (1.98644 × 10⁻¹⁹) / λ(m)
ν(cm⁻¹) = 10⁷ / λ(nm)
ν(Hz) = c / λ = (2.998 × 10⁸) / λ(m)
```

### Absorbance-Transmittance

```
A = -log₁₀(T)
T = 10⁻ᴬ
%T = 100 × T
```

### Unit Conversions

| From | To | Factor |
|------|-----|--------|
| nm | μm | ×0.001 |
| nm | Å | ×10 |
| eV | J | ×1.602×10⁻¹⁹ |
| cm⁻¹ | meV | ×0.124 |

---

## Support & Resources

### Technical Support

**Email:** optical-support@semiconductorlab.com  
**Phone:** +1-555-0123 (24/7)  
**Portal:** https://support.semiconductorlab.com

### Training Resources

- **Online Courses:** https://learn.semiconductorlab.com/optical
- **Video Tutorials:** YouTube @SemiconductorLab
- **Webinars:** Monthly, register at website

### Community

- **User Forum:** https://forum.semiconductorlab.com
- **GitHub:** https://github.com/semiconductor-lab
- **LinkedIn:** Semiconductor Lab Users Group

### References

1. Tauc, J. (1968). "Optical properties and electronic structure of amorphous Ge and Si"
2. Swanepoel, R. (1983). "Determination of the thickness and optical constants of amorphous silicon"
3. ASTM E903-12: "Standard Test Method for Solar Absorptance, Reflectance, and Transmittance"
4. ISO 20473:2007: "Optics and photonics — Spectral bands"

---

**Document Version:** 1.0.0  
**Last Updated:** October 24, 2025  
**Next Review:** January 24, 2026

---

*© 2025 Semiconductor Lab Platform. All rights reserved.*
