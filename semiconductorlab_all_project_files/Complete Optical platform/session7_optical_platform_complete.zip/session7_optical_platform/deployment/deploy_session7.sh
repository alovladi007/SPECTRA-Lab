#!/bin/bash

################################################################################
# Session 7: Optical I - Deployment Script
# UV-Vis-NIR and FTIR Spectroscopy Platform
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DEPLOYMENT_ENV=${1:-staging}
VERSION="1.0.0"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="deployment_session7_${TIMESTAMP}.log"

################################################################################
# Helper Functions
################################################################################

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a $LOG_FILE
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a $LOG_FILE
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a $LOG_FILE
}

info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a $LOG_FILE
}

check_command() {
    if ! command -v $1 &> /dev/null; then
        error "$1 is not installed. Please install $1 and try again."
    fi
}

################################################################################
# Pre-deployment Checks
################################################################################

pre_deployment_checks() {
    log "Starting pre-deployment checks..."
    
    # Check required commands
    check_command docker
    check_command docker-compose
    check_command python3
    check_command npm
    check_command git
    
    # Check Python version
    python_version=$(python3 --version | cut -d' ' -f2)
    info "Python version: $python_version"
    
    # Check Node version
    node_version=$(node --version)
    info "Node version: $node_version"
    
    # Check Docker status
    if ! docker info &> /dev/null; then
        error "Docker is not running. Please start Docker."
    fi
    
    # Check disk space
    available_space=$(df -h /var/lib/docker | awk 'NR==2 {print $4}')
    info "Available disk space: $available_space"
    
    log "Pre-deployment checks completed ✓"
}

################################################################################
# Environment Setup
################################################################################

setup_environment() {
    log "Setting up environment..."
    
    # Create necessary directories
    mkdir -p logs
    mkdir -p data/{uploads,outputs,temp}
    mkdir -p backups
    mkdir -p config
    
    # Setup environment variables
    cat > .env.session7 <<EOF
# Session 7 Optical Configuration
DEPLOYMENT_ENV=${DEPLOYMENT_ENV}
VERSION=${VERSION}

# Database
DB_HOST=postgres
DB_PORT=5432
DB_NAME=semiconductor_lab
DB_USER=semiconductor_user
DB_PASSWORD=$(openssl rand -base64 32)

# Redis
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_DB=0

# MinIO/S3
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=semiconductor_admin
S3_SECRET_KEY=$(openssl rand -base64 32)
S3_BUCKET=optical-data

# API Settings
API_PORT=8007
API_WORKERS=4
API_TIMEOUT=300

# Frontend Settings
FRONTEND_PORT=3007
NEXT_PUBLIC_API_URL=http://localhost:8007

# Optical Module Settings
UV_VIS_WAVELENGTH_MIN=200
UV_VIS_WAVELENGTH_MAX=3300
FTIR_WAVENUMBER_MIN=400
FTIR_WAVENUMBER_MAX=4000

# Data Processing
MAX_SPECTRUM_SIZE_MB=100
BATCH_PROCESSING_ENABLED=true
MAX_CONCURRENT_ANALYSES=10

# Instrument Drivers
ENABLE_MOCK_INSTRUMENTS=true
INSTRUMENT_TIMEOUT=30

# Security
JWT_SECRET=$(openssl rand -base64 32)
ENCRYPTION_KEY=$(openssl rand -base64 32)
EOF
    
    log "Environment setup completed ✓"
}

################################################################################
# Database Setup
################################################################################

setup_database() {
    log "Setting up database..."
    
    # Create migration file for Session 7 tables
    cat > migrations/session7_optical.sql <<'EOF'
-- Session 7: Optical Spectroscopy Tables

-- UV-Vis-NIR measurements table
CREATE TABLE IF NOT EXISTS uv_vis_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sample_id UUID REFERENCES samples(id),
    user_id UUID REFERENCES users(id),
    instrument_id UUID REFERENCES instruments(id),
    
    -- Measurement parameters
    wavelength_start REAL NOT NULL,
    wavelength_end REAL NOT NULL,
    wavelength_step REAL NOT NULL,
    scan_speed REAL,
    slit_width REAL,
    integration_time REAL,
    average_scans INTEGER DEFAULT 1,
    measurement_mode VARCHAR(50),
    
    -- Raw data
    wavelength_data REAL[],
    intensity_data REAL[],
    reference_spectrum REAL[],
    dark_spectrum REAL[],
    
    -- Analysis results
    baseline REAL[],
    corrected_intensity REAL[],
    peaks JSONB,
    band_gap JSONB,
    interference_analysis JSONB,
    quality_metrics JSONB,
    
    -- Metadata
    temperature REAL,
    humidity REAL,
    notes TEXT,
    tags TEXT[],
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    analyzed_at TIMESTAMP
);

-- FTIR measurements table
CREATE TABLE IF NOT EXISTS ftir_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sample_id UUID REFERENCES samples(id),
    user_id UUID REFERENCES users(id),
    instrument_id UUID REFERENCES instruments(id),
    
    -- Measurement parameters
    wavenumber_start REAL NOT NULL,
    wavenumber_end REAL NOT NULL,
    resolution REAL NOT NULL,
    number_of_scans INTEGER NOT NULL,
    apodization VARCHAR(50),
    detector_type VARCHAR(50),
    beam_splitter VARCHAR(50),
    purge_gas BOOLEAN DEFAULT false,
    
    -- Raw data
    wavenumber_data REAL[],
    intensity_data REAL[],
    background_spectrum REAL[],
    interferogram REAL[],
    
    -- Analysis results
    baseline REAL[],
    corrected_intensity REAL[],
    absorbance_data REAL[],
    peaks JSONB,
    functional_groups JSONB,
    quality_metrics JSONB,
    
    -- Metadata
    sample_preparation VARCHAR(100),
    temperature REAL,
    humidity REAL,
    notes TEXT,
    tags TEXT[],
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    analyzed_at TIMESTAMP
);

-- Spectral libraries table
CREATE TABLE IF NOT EXISTS spectral_libraries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    material_type VARCHAR(100),
    cas_number VARCHAR(50),
    
    -- Spectral data
    spectrum_type VARCHAR(50), -- 'uv_vis' or 'ftir'
    x_data REAL[], -- wavelength or wavenumber
    y_data REAL[], -- intensity
    
    -- Properties
    molecular_formula VARCHAR(100),
    molecular_weight REAL,
    physical_state VARCHAR(50),
    purity VARCHAR(50),
    
    -- Source information
    source VARCHAR(255),
    reference VARCHAR(500),
    measurement_conditions JSONB,
    
    -- Metadata
    tags TEXT[],
    verified BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Peak assignments table
CREATE TABLE IF NOT EXISTS peak_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    measurement_id UUID NOT NULL, -- Can reference either uv_vis or ftir
    measurement_type VARCHAR(50) NOT NULL, -- 'uv_vis' or 'ftir'
    
    peak_position REAL NOT NULL,
    peak_intensity REAL,
    peak_width REAL,
    
    assignment VARCHAR(255),
    functional_group VARCHAR(100),
    vibration_mode VARCHAR(100),
    confidence REAL,
    
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_uv_vis_sample ON uv_vis_measurements(sample_id);
CREATE INDEX idx_uv_vis_created ON uv_vis_measurements(created_at);
CREATE INDEX idx_ftir_sample ON ftir_measurements(sample_id);
CREATE INDEX idx_ftir_created ON ftir_measurements(created_at);
CREATE INDEX idx_spectral_lib_type ON spectral_libraries(spectrum_type);
CREATE INDEX idx_spectral_lib_material ON spectral_libraries(material_type);
CREATE INDEX idx_peak_measurement ON peak_assignments(measurement_id, measurement_type);

-- Create views
CREATE OR REPLACE VIEW recent_optical_measurements AS
SELECT 
    'uv_vis' as type,
    id,
    sample_id,
    user_id,
    created_at,
    analyzed_at,
    quality_metrics->>'signal_to_noise' as snr
FROM uv_vis_measurements
UNION ALL
SELECT 
    'ftir' as type,
    id,
    sample_id,
    user_id,
    created_at,
    analyzed_at,
    quality_metrics->>'signal_to_noise' as snr
FROM ftir_measurements
ORDER BY created_at DESC;

-- Add constraints
ALTER TABLE uv_vis_measurements 
    ADD CONSTRAINT check_wavelength_range 
    CHECK (wavelength_start < wavelength_end);

ALTER TABLE ftir_measurements 
    ADD CONSTRAINT check_wavenumber_range 
    CHECK (wavenumber_start < wavenumber_end);

-- Grant permissions
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO semiconductor_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO semiconductor_user;
EOF
    
    # Run migrations
    log "Running database migrations..."
    docker-compose exec -T postgres psql -U semiconductor_user -d semiconductor_lab < migrations/session7_optical.sql
    
    log "Database setup completed ✓"
}

################################################################################
# Backend Deployment
################################################################################

deploy_backend() {
    log "Deploying backend services..."
    
    # Create backend Dockerfile
    cat > backend/Dockerfile.session7 <<'EOF'
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    libhdf5-dev \
    libnetcdf-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8007", "--workers", "4"]
EOF
    
    # Create requirements.txt
    cat > backend/requirements.txt <<'EOF'
# Core dependencies
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.4.2
python-multipart==0.0.6

# Scientific computing
numpy==1.24.3
scipy==1.11.4
pandas==2.1.3
scikit-learn==1.3.2

# Database
sqlalchemy==2.0.23
asyncpg==0.29.0
alembic==1.12.1

# Spectroscopy specific
h5py==3.10.0
netCDF4==1.6.5

# Testing
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-benchmark==4.0.0

# Utilities
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-dotenv==1.0.0
redis==5.0.1
minio==7.2.0

# Instrument communication
pyvisa==1.13.0
pyvisa-py==0.7.0
pyserial==3.5
EOF
    
    # Build and start backend service
    docker build -f backend/Dockerfile.session7 -t optical-backend:${VERSION} ./backend
    
    log "Backend deployment completed ✓"
}

################################################################################
# Frontend Deployment
################################################################################

deploy_frontend() {
    log "Deploying frontend application..."
    
    # Create frontend Dockerfile
    cat > frontend/Dockerfile.session7 <<'EOF'
FROM node:18-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./
RUN npm ci --only=production

# Copy application code
COPY . .

# Build application
RUN npm run build

# Production stage
FROM node:18-alpine

WORKDIR /app

# Copy built application
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/package*.json ./
COPY --from=builder /app/node_modules ./node_modules

EXPOSE 3007

CMD ["npm", "start"]
EOF
    
    # Create package.json
    cat > frontend/package.json <<'EOF'
{
  "name": "optical-spectroscopy-ui",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev -p 3007",
    "build": "next build",
    "start": "next start -p 3007",
    "test": "jest"
  },
  "dependencies": {
    "next": "14.0.3",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "@radix-ui/react-alert-dialog": "^1.0.5",
    "@radix-ui/react-select": "^2.0.0",
    "@radix-ui/react-slider": "^1.1.2",
    "@radix-ui/react-switch": "^1.0.3",
    "@radix-ui/react-tabs": "^1.0.4",
    "recharts": "^2.10.3",
    "lucide-react": "^0.294.0",
    "axios": "^1.6.2"
  },
  "devDependencies": {
    "@types/node": "20.10.3",
    "@types/react": "18.2.42",
    "typescript": "5.3.2",
    "tailwindcss": "3.3.6",
    "autoprefixer": "10.4.16",
    "postcss": "8.4.32",
    "jest": "^29.7.0",
    "@testing-library/react": "^14.1.2"
  }
}
EOF
    
    # Build and start frontend service
    docker build -f frontend/Dockerfile.session7 -t optical-frontend:${VERSION} ./frontend
    
    log "Frontend deployment completed ✓"
}

################################################################################
# Docker Compose Configuration
################################################################################

create_docker_compose() {
    log "Creating Docker Compose configuration..."
    
    cat > docker-compose.session7.yml <<'EOF'
version: '3.8'

services:
  # Backend API
  optical-backend:
    image: optical-backend:1.0.0
    container_name: optical-backend
    env_file:
      - .env.session7
    ports:
      - "8007:8007"
    volumes:
      - ./backend:/app
      - ./data:/data
      - ./logs:/logs
    depends_on:
      - postgres
      - redis
      - minio
    networks:
      - semiconductor-net
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8007/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Frontend UI
  optical-frontend:
    image: optical-frontend:1.0.0
    container_name: optical-frontend
    env_file:
      - .env.session7
    ports:
      - "3007:3007"
    volumes:
      - ./frontend:/app
    depends_on:
      - optical-backend
    networks:
      - semiconductor-net
    restart: unless-stopped

  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: postgres
    environment:
      POSTGRES_DB: semiconductor_lab
      POSTGRES_USER: semiconductor_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./migrations:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    networks:
      - semiconductor-net
    restart: unless-stopped

  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - semiconductor-net
    restart: unless-stopped

  # MinIO Object Storage
  minio:
    image: minio/minio:latest
    container_name: minio
    environment:
      MINIO_ROOT_USER: ${S3_ACCESS_KEY}
      MINIO_ROOT_PASSWORD: ${S3_SECRET_KEY}
    command: server /data --console-address ":9001"
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/data
    networks:
      - semiconductor-net
    restart: unless-stopped

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - optical-backend
      - optical-frontend
    networks:
      - semiconductor-net
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
  minio_data:

networks:
  semiconductor-net:
    driver: bridge
EOF
    
    log "Docker Compose configuration created ✓"
}

################################################################################
# Nginx Configuration
################################################################################

create_nginx_config() {
    log "Creating Nginx configuration..."
    
    cat > nginx.conf <<'EOF'
events {
    worker_connections 1024;
}

http {
    upstream optical_backend {
        server optical-backend:8007;
    }

    upstream optical_frontend {
        server optical-frontend:3007;
    }

    server {
        listen 80;
        server_name localhost;

        # Frontend
        location / {
            proxy_pass http://optical_frontend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }

        # Backend API
        location /api/ {
            proxy_pass http://optical_backend;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # Increase timeout for long-running analyses
            proxy_connect_timeout 300;
            proxy_send_timeout 300;
            proxy_read_timeout 300;
        }

        # WebSocket support
        location /ws/ {
            proxy_pass http://optical_backend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "Upgrade";
            proxy_set_header Host $host;
        }

        # Health check endpoint
        location /health {
            access_log off;
            return 200 "healthy\n";
        }
    }
}
EOF
    
    log "Nginx configuration created ✓"
}

################################################################################
# Load Test Data
################################################################################

load_test_data() {
    log "Loading test data and spectral libraries..."
    
    # Create Python script to load test data
    cat > load_test_data.py <<'EOF'
import psycopg2
import json
import numpy as np
from datetime import datetime

# Database connection
conn = psycopg2.connect(
    host="localhost",
    database="semiconductor_lab",
    user="semiconductor_user",
    password=os.environ.get("DB_PASSWORD")
)
cur = conn.cursor()

# Load spectral libraries
spectral_libraries = [
    {
        "name": "Polystyrene",
        "material_type": "polymer",
        "cas_number": "9003-53-6",
        "spectrum_type": "ftir",
        "molecular_formula": "(C8H8)n",
        "source": "NIST",
        "verified": True
    },
    {
        "name": "Silicon",
        "material_type": "semiconductor",
        "spectrum_type": "uv_vis",
        "molecular_formula": "Si",
        "source": "Reference Standard",
        "verified": True
    },
    {
        "name": "Gallium Arsenide",
        "material_type": "semiconductor",
        "cas_number": "1303-00-0",
        "spectrum_type": "uv_vis",
        "molecular_formula": "GaAs",
        "source": "Reference Standard",
        "verified": True
    }
]

for lib in spectral_libraries:
    cur.execute("""
        INSERT INTO spectral_libraries (
            name, material_type, cas_number, spectrum_type,
            molecular_formula, source, verified
        ) VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (
        lib["name"], lib["material_type"], lib.get("cas_number"),
        lib["spectrum_type"], lib.get("molecular_formula"),
        lib["source"], lib["verified"]
    ))

conn.commit()
cur.close()
conn.close()

print("Test data loaded successfully!")
EOF
    
    python3 load_test_data.py
    
    log "Test data loaded ✓"
}

################################################################################
# Health Checks
################################################################################

health_checks() {
    log "Running health checks..."
    
    # Wait for services to start
    sleep 10
    
    # Check backend health
    if curl -f http://localhost:8007/health > /dev/null 2>&1; then
        log "Backend health check: ✓"
    else
        warning "Backend health check failed"
    fi
    
    # Check frontend health
    if curl -f http://localhost:3007 > /dev/null 2>&1; then
        log "Frontend health check: ✓"
    else
        warning "Frontend health check failed"
    fi
    
    # Check database connection
    if docker-compose exec -T postgres pg_isready > /dev/null 2>&1; then
        log "Database health check: ✓"
    else
        warning "Database health check failed"
    fi
    
    log "Health checks completed"
}

################################################################################
# Run Tests
################################################################################

run_tests() {
    log "Running test suite..."
    
    # Run backend tests
    docker-compose exec -T optical-backend pytest tests/ -v
    
    # Run frontend tests
    docker-compose exec -T optical-frontend npm test
    
    log "Tests completed"
}

################################################################################
# Cleanup
################################################################################

cleanup() {
    log "Cleaning up temporary files..."
    
    rm -f load_test_data.py
    
    log "Cleanup completed ✓"
}

################################################################################
# Main Deployment Flow
################################################################################

main() {
    echo "================================"
    echo "Session 7: Optical I Deployment"
    echo "Environment: ${DEPLOYMENT_ENV}"
    echo "Version: ${VERSION}"
    echo "================================"
    
    # Run deployment steps
    pre_deployment_checks
    setup_environment
    create_docker_compose
    create_nginx_config
    
    # Start services
    log "Starting services..."
    docker-compose -f docker-compose.session7.yml up -d
    
    # Setup database
    setup_database
    
    # Deploy components
    deploy_backend
    deploy_frontend
    
    # Load test data
    if [ "$DEPLOYMENT_ENV" != "production" ]; then
        load_test_data
    fi
    
    # Verify deployment
    health_checks
    
    # Run tests in non-production environments
    if [ "$DEPLOYMENT_ENV" != "production" ]; then
        run_tests
    fi
    
    # Cleanup
    cleanup
    
    echo ""
    echo "================================"
    echo "Deployment completed successfully!"
    echo "================================"
    echo ""
    echo "Access points:"
    echo "  Frontend: http://localhost:3007"
    echo "  Backend API: http://localhost:8007"
    echo "  API Documentation: http://localhost:8007/docs"
    echo "  MinIO Console: http://localhost:9001"
    echo ""
    echo "Default credentials:"
    echo "  Check .env.session7 for generated passwords"
    echo ""
    echo "Logs: tail -f ${LOG_FILE}"
}

# Run main function
main "$@"
