# backend/optical_analysis_session7.py
"""
Session 7: Optical I - UV-Vis-NIR and FTIR Analysis Modules
Comprehensive spectroscopy analysis with band gap determination, peak fitting, and baseline correction
"""

import numpy as np
import pandas as pd
from scipy import signal, optimize, interpolate
from scipy.special import voigt_profile, wofz
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum
import warnings
from datetime import datetime
import hashlib
import json

# ============================================================================
# Data Models
# ============================================================================

class SpectrumType(str, Enum):
    """Types of optical spectra"""
    ABSORPTION = "absorption"
    TRANSMISSION = "transmission"
    REFLECTANCE = "reflectance"
    ABSORBANCE = "absorbance"
    TRANSMITTANCE = "transmittance"

class BandGapType(str, Enum):
    """Types of band gap transitions"""
    DIRECT_ALLOWED = "direct_allowed"
    INDIRECT_ALLOWED = "indirect_allowed"
    DIRECT_FORBIDDEN = "direct_forbidden"
    INDIRECT_FORBIDDEN = "indirect_forbidden"

class BaselineMethod(str, Enum):
    """Baseline correction methods"""
    POLYNOMIAL = "polynomial"
    ASYMMETRIC_LEAST_SQUARES = "als"
    SAVITZKY_GOLAY = "savgol"
    RUBBERBAND = "rubberband"
    SNIP = "snip"
    MORPHOLOGICAL = "morphological"

class PeakShape(str, Enum):
    """Peak fitting functions"""
    GAUSSIAN = "gaussian"
    LORENTZIAN = "lorentzian"
    VOIGT = "voigt"
    PSEUDO_VOIGT = "pseudo_voigt"
    ASYMMETRIC_GAUSSIAN = "asymmetric_gaussian"

@dataclass
class OpticalSpectrum:
    """Container for optical spectrum data"""
    wavelength: np.ndarray  # nm for UV-Vis-NIR
    intensity: np.ndarray
    spectrum_type: SpectrumType
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Derived properties
    wavenumber: Optional[np.ndarray] = None  # cm^-1 for FTIR
    energy: Optional[np.ndarray] = None  # eV
    frequency: Optional[np.ndarray] = None  # Hz
    
    # Analysis results
    baseline: Optional[np.ndarray] = None
    corrected_intensity: Optional[np.ndarray] = None
    peaks: Optional[List[Dict]] = None
    band_gap: Optional[Dict] = None
    
    def __post_init__(self):
        """Calculate derived properties"""
        # Physical constants
        h = 6.62607015e-34  # Planck constant (J·s)
        c = 2.99792458e8    # Speed of light (m/s)
        e = 1.602176634e-19 # Elementary charge (C)
        
        # Calculate energy in eV
        self.energy = (h * c) / (self.wavelength * 1e-9) / e
        
        # Calculate frequency in Hz
        self.frequency = c / (self.wavelength * 1e-9)
        
        # Calculate wavenumber in cm^-1
        self.wavenumber = 1e7 / self.wavelength

@dataclass
class FTIRSpectrum:
    """Container for FTIR spectrum data"""
    wavenumber: np.ndarray  # cm^-1
    intensity: np.ndarray
    spectrum_type: SpectrumType
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Interferogram data (if available)
    interferogram: Optional[np.ndarray] = None
    mirror_position: Optional[np.ndarray] = None
    
    # Analysis results
    baseline: Optional[np.ndarray] = None
    corrected_intensity: Optional[np.ndarray] = None
    peaks: Optional[List[Dict]] = None
    functional_groups: Optional[List[Dict]] = None
    
    def __post_init__(self):
        """Calculate derived properties"""
        # Convert to wavelength in nm if needed
        self.wavelength = 1e7 / self.wavenumber

# ============================================================================
# UV-Vis-NIR Analyzer
# ============================================================================

class UVVisNIRAnalyzer:
    """
    Analyzer for UV-Vis-NIR spectroscopy data
    
    Capabilities:
    - Absorption, transmission, reflectance analysis
    - Band gap determination (Tauc plots)
    - Thin film interference analysis
    - Peak detection and fitting
    - Baseline correction
    """
    
    def __init__(self):
        self.spectrum = None
        self.results = {}
        
    def load_spectrum(self, wavelength: np.ndarray, intensity: np.ndarray,
                      spectrum_type: SpectrumType, **metadata) -> OpticalSpectrum:
        """Load spectrum data"""
        self.spectrum = OpticalSpectrum(
            wavelength=np.array(wavelength),
            intensity=np.array(intensity),
            spectrum_type=spectrum_type,
            metadata=metadata
        )
        return self.spectrum
    
    def convert_spectrum_type(self, target_type: SpectrumType) -> np.ndarray:
        """Convert between different spectrum representations"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
            
        intensity = self.spectrum.intensity
        current_type = self.spectrum.spectrum_type
        
        # Conversion matrix
        if current_type == SpectrumType.TRANSMISSION:
            if target_type == SpectrumType.ABSORPTION:
                return -np.log10(intensity)
            elif target_type == SpectrumType.REFLECTANCE:
                # Approximate for thin films
                return 1 - intensity
                
        elif current_type == SpectrumType.ABSORPTION:
            if target_type == SpectrumType.TRANSMISSION:
                return 10**(-intensity)
            elif target_type == SpectrumType.REFLECTANCE:
                return 1 - 10**(-intensity)
                
        elif current_type == SpectrumType.REFLECTANCE:
            if target_type == SpectrumType.TRANSMISSION:
                return 1 - intensity
            elif target_type == SpectrumType.ABSORPTION:
                return -np.log10(1 - intensity)
        
        return intensity
    
    def correct_baseline(self, method: BaselineMethod = BaselineMethod.POLYNOMIAL,
                        **kwargs) -> np.ndarray:
        """Apply baseline correction"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
            
        intensity = self.spectrum.intensity
        x = self.spectrum.wavelength
        
        if method == BaselineMethod.POLYNOMIAL:
            order = kwargs.get('order', 3)
            # Fit polynomial to minima
            baseline = self._polynomial_baseline(x, intensity, order)
            
        elif method == BaselineMethod.ASYMMETRIC_LEAST_SQUARES:
            lam = kwargs.get('lambda', 1e6)
            p = kwargs.get('p', 0.01)
            baseline = self._als_baseline(intensity, lam, p)
            
        elif method == BaselineMethod.SAVITZKY_GOLAY:
            window = kwargs.get('window', 21)
            order = kwargs.get('order', 3)
            baseline = signal.savgol_filter(intensity, window, order)
            
        elif method == BaselineMethod.RUBBERBAND:
            baseline = self._rubberband_baseline(x, intensity)
            
        else:
            baseline = np.zeros_like(intensity)
        
        self.spectrum.baseline = baseline
        self.spectrum.corrected_intensity = intensity - baseline
        
        return self.spectrum.corrected_intensity
    
    def _polynomial_baseline(self, x: np.ndarray, y: np.ndarray, order: int) -> np.ndarray:
        """Polynomial baseline fitting"""
        # Find local minima
        minima = signal.argrelextrema(y, np.less, order=20)[0]
        if len(minima) < order + 1:
            minima = np.linspace(0, len(y)-1, order+2, dtype=int)
        
        # Fit polynomial to minima
        coef = np.polyfit(x[minima], y[minima], order)
        baseline = np.polyval(coef, x)
        
        return baseline
    
    def _als_baseline(self, y: np.ndarray, lam: float, p: float, niter: int = 10) -> np.ndarray:
        """Asymmetric least squares baseline"""
        L = len(y)
        D = np.diff(np.eye(L), 2)
        w = np.ones(L)
        
        for _ in range(niter):
            W = np.diag(w)
            Z = W + lam * D.T @ D
            z = np.linalg.solve(Z, w * y)
            w = p * (y > z) + (1 - p) * (y < z)
            
        return z
    
    def _rubberband_baseline(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Rubberband baseline correction"""
        # Convex hull approach
        from scipy.spatial import ConvexHull
        
        points = np.column_stack((x, y))
        hull = ConvexHull(points)
        
        # Get lower hull
        lower_hull_idx = []
        for simplex in hull.simplices:
            if all(points[simplex, 1] <= np.mean(y)):
                lower_hull_idx.extend(simplex)
        
        lower_hull_idx = sorted(set(lower_hull_idx))
        
        if len(lower_hull_idx) < 2:
            return np.zeros_like(y)
        
        # Interpolate baseline
        baseline_func = interpolate.interp1d(
            x[lower_hull_idx], y[lower_hull_idx],
            kind='linear', fill_value='extrapolate'
        )
        
        return baseline_func(x)
    
    def calculate_band_gap(self, band_gap_type: BandGapType = BandGapType.DIRECT_ALLOWED,
                          energy_range: Optional[Tuple[float, float]] = None) -> Dict[str, Any]:
        """
        Calculate optical band gap using Tauc plot method
        
        (αhν)^n = B(hν - Eg)
        where n = 1/2 (indirect), 2 (direct)
        """
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Get absorption coefficient
        if self.spectrum.spectrum_type != SpectrumType.ABSORPTION:
            absorption = self.convert_spectrum_type(SpectrumType.ABSORPTION)
        else:
            absorption = self.spectrum.intensity
        
        # Calculate absorption coefficient (assuming unit path length)
        alpha = absorption * 2.303  # Convert from absorbance to absorption coefficient
        
        # Energy in eV
        energy = self.spectrum.energy
        
        # Select Tauc exponent
        if band_gap_type == BandGapType.DIRECT_ALLOWED:
            n = 2
        elif band_gap_type == BandGapType.INDIRECT_ALLOWED:
            n = 0.5
        elif band_gap_type == BandGapType.DIRECT_FORBIDDEN:
            n = 2/3
        else:  # INDIRECT_FORBIDDEN
            n = 1/3
        
        # Calculate Tauc function
        tauc_y = (alpha * energy) ** n
        
        # Determine fitting range
        if energy_range is None:
            # Auto-detect linear region
            energy_range = self._detect_linear_region(energy, tauc_y)
        
        # Fit linear region
        mask = (energy >= energy_range[0]) & (energy <= energy_range[1])
        x_fit = energy[mask]
        y_fit = tauc_y[mask]
        
        # Linear regression
        coef = np.polyfit(x_fit, y_fit, 1)
        
        # Band gap is x-intercept
        band_gap_ev = -coef[1] / coef[0] if coef[0] != 0 else 0
        
        # Calculate R-squared
        y_pred = np.polyval(coef, x_fit)
        ss_res = np.sum((y_fit - y_pred) ** 2)
        ss_tot = np.sum((y_fit - np.mean(y_fit)) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        
        # Store results
        self.spectrum.band_gap = {
            'value_ev': band_gap_ev,
            'value_nm': 1239.84 / band_gap_ev if band_gap_ev > 0 else np.inf,
            'type': band_gap_type.value,
            'tauc_exponent': n,
            'fit_range_ev': energy_range,
            'fit_coefficients': coef.tolist(),
            'r_squared': r_squared,
            'tauc_data': {
                'energy': energy.tolist(),
                'tauc_y': tauc_y.tolist()
            }
        }
        
        return self.spectrum.band_gap
    
    def _detect_linear_region(self, x: np.ndarray, y: np.ndarray,
                              window_fraction: float = 0.2) -> Tuple[float, float]:
        """Auto-detect linear region in Tauc plot"""
        # Calculate derivative
        dy_dx = np.gradient(y, x)
        
        # Find region with maximum derivative (steepest slope)
        window_size = int(len(x) * window_fraction)
        
        max_slope_idx = np.argmax(dy_dx)
        
        # Extend region around maximum
        start_idx = max(0, max_slope_idx - window_size // 2)
        end_idx = min(len(x) - 1, max_slope_idx + window_size // 2)
        
        return (x[start_idx], x[end_idx])
    
    def detect_peaks(self, min_height: Optional[float] = None,
                     min_distance: int = 10, prominence: float = 0.1) -> List[Dict]:
        """Detect peaks in spectrum"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Use corrected intensity if available
        intensity = (self.spectrum.corrected_intensity 
                    if self.spectrum.corrected_intensity is not None 
                    else self.spectrum.intensity)
        
        # Find peaks
        peaks, properties = signal.find_peaks(
            intensity,
            height=min_height,
            distance=min_distance,
            prominence=prominence
        )
        
        # Compile peak information
        peak_list = []
        for i, peak_idx in enumerate(peaks):
            peak_info = {
                'index': int(peak_idx),
                'wavelength': float(self.spectrum.wavelength[peak_idx]),
                'intensity': float(intensity[peak_idx]),
                'energy_ev': float(self.spectrum.energy[peak_idx]),
                'wavenumber': float(self.spectrum.wavenumber[peak_idx]),
                'prominence': float(properties['prominences'][i]),
                'width': float(properties.get('widths', [0])[i] if 'widths' in properties else 0)
            }
            
            # Estimate FWHM
            if peak_info['width'] > 0:
                peak_info['fwhm_nm'] = peak_info['width'] * np.mean(np.diff(self.spectrum.wavelength))
            
            peak_list.append(peak_info)
        
        self.spectrum.peaks = peak_list
        return peak_list
    
    def analyze_interference(self, refractive_index: float = 1.5) -> Dict[str, Any]:
        """
        Analyze thin film interference patterns
        Calculate film thickness from fringe spacing
        """
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Find extrema (maxima and minima)
        intensity = (self.spectrum.corrected_intensity 
                    if self.spectrum.corrected_intensity is not None 
                    else self.spectrum.intensity)
        
        maxima = signal.argrelextrema(intensity, np.greater, order=10)[0]
        minima = signal.argrelextrema(intensity, np.less, order=10)[0]
        
        if len(maxima) < 2 and len(minima) < 2:
            return {'error': 'Insufficient interference fringes'}
        
        # Use maxima for calculation
        extrema = maxima if len(maxima) >= len(minima) else minima
        wavelengths = self.spectrum.wavelength[extrema]
        
        # Calculate thickness from adjacent fringes
        # d = λ₁λ₂ / (2n(λ₂ - λ₁))
        thicknesses = []
        for i in range(len(wavelengths) - 1):
            λ1, λ2 = wavelengths[i], wavelengths[i + 1]
            d = (λ1 * λ2) / (2 * refractive_index * abs(λ2 - λ1))
            thicknesses.append(d)
        
        # Statistics
        if thicknesses:
            mean_thickness = np.mean(thicknesses)
            std_thickness = np.std(thicknesses)
            
            return {
                'thickness_nm': mean_thickness,
                'thickness_std': std_thickness,
                'num_fringes': len(extrema),
                'fringe_wavelengths': wavelengths.tolist(),
                'refractive_index': refractive_index,
                'individual_thicknesses': thicknesses
            }
        else:
            return {'error': 'Could not calculate thickness'}

# ============================================================================
# FTIR Analyzer
# ============================================================================

class FTIRAnalyzer:
    """
    Analyzer for FTIR spectroscopy data
    
    Capabilities:
    - Interferogram to spectrum conversion
    - Baseline correction
    - Peak detection and fitting
    - Functional group identification
    - Spectral matching
    """
    
    def __init__(self):
        self.spectrum = None
        self.results = {}
        self._load_functional_groups()
    
    def _load_functional_groups(self):
        """Load database of common functional groups"""
        self.functional_groups = {
            'O-H stretch (alcohol)': {'range': (3200, 3600), 'shape': 'broad'},
            'O-H stretch (carboxylic acid)': {'range': (2500, 3300), 'shape': 'very broad'},
            'N-H stretch (amine)': {'range': (3300, 3500), 'shape': 'medium'},
            'C-H stretch (alkane)': {'range': (2850, 3000), 'shape': 'strong'},
            'C-H stretch (alkene)': {'range': (3020, 3100), 'shape': 'medium'},
            'C-H stretch (aromatic)': {'range': (3000, 3100), 'shape': 'medium'},
            'C≡N stretch (nitrile)': {'range': (2210, 2260), 'shape': 'medium'},
            'C≡C stretch (alkyne)': {'range': (2100, 2260), 'shape': 'weak'},
            'C=O stretch (carbonyl)': {'range': (1670, 1780), 'shape': 'strong'},
            'C=O stretch (amide I)': {'range': (1630, 1680), 'shape': 'strong'},
            'C=C stretch (alkene)': {'range': (1620, 1680), 'shape': 'variable'},
            'C=C stretch (aromatic)': {'range': (1450, 1600), 'shape': 'multiple'},
            'N-H bend (amide II)': {'range': (1510, 1570), 'shape': 'medium'},
            'C-H bend (alkane)': {'range': (1350, 1470), 'shape': 'variable'},
            'C-O stretch (alcohol)': {'range': (1000, 1300), 'shape': 'strong'},
            'C-O stretch (ether)': {'range': (1000, 1300), 'shape': 'strong'},
            'C-N stretch (amine)': {'range': (1020, 1250), 'shape': 'medium'},
            'C=S stretch': {'range': (1050, 1200), 'shape': 'strong'},
            'Si-O stretch': {'range': (1000, 1100), 'shape': 'strong'},
            'C-Cl stretch': {'range': (600, 800), 'shape': 'strong'},
            'C-Br stretch': {'range': (500, 600), 'shape': 'strong'},
        }
    
    def load_spectrum(self, wavenumber: np.ndarray, intensity: np.ndarray,
                      spectrum_type: SpectrumType = SpectrumType.TRANSMITTANCE,
                      **metadata) -> FTIRSpectrum:
        """Load FTIR spectrum data"""
        self.spectrum = FTIRSpectrum(
            wavenumber=np.array(wavenumber),
            intensity=np.array(intensity),
            spectrum_type=spectrum_type,
            metadata=metadata
        )
        return self.spectrum
    
    def process_interferogram(self, interferogram: np.ndarray,
                             mirror_position: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        Convert interferogram to spectrum using FFT
        
        Returns:
            wavenumber, intensity arrays
        """
        # Apply apodization (Happ-Genzel is common)
        window = self._happ_genzel_apodization(len(interferogram))
        interferogram_windowed = interferogram * window
        
        # Zero padding for improved resolution
        n_points = len(interferogram)
        n_padded = 2 ** int(np.ceil(np.log2(n_points * 4)))
        
        # Perform FFT
        spectrum = np.fft.rfft(interferogram_windowed, n_padded)
        
        # Calculate wavenumber scale
        if mirror_position is not None:
            delta = np.mean(np.diff(mirror_position))
        else:
            delta = 0.000632  # Assume He-Ne laser wavelength in cm
        
        wavenumber = np.fft.rfftfreq(n_padded, delta)
        
        # Take magnitude and apply phase correction
        intensity = np.abs(spectrum)
        
        # Limit to typical FTIR range
        mask = (wavenumber >= 400) & (wavenumber <= 4000)
        
        return wavenumber[mask], intensity[mask]
    
    def _happ_genzel_apodization(self, n: int) -> np.ndarray:
        """Happ-Genzel apodization function"""
        x = np.arange(n) / (n - 1)
        return 0.54 + 0.46 * np.cos(2 * np.pi * x)
    
    def convert_to_absorbance(self) -> np.ndarray:
        """Convert transmittance to absorbance"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        if self.spectrum.spectrum_type == SpectrumType.TRANSMITTANCE:
            # A = -log10(T/100) if T is in percentage
            if np.max(self.spectrum.intensity) > 1.1:
                # Assume percentage
                absorbance = -np.log10(self.spectrum.intensity / 100)
            else:
                # Assume fraction
                absorbance = -np.log10(self.spectrum.intensity)
            
            return absorbance
        else:
            return self.spectrum.intensity
    
    def correct_baseline(self, method: BaselineMethod = BaselineMethod.ASYMMETRIC_LEAST_SQUARES,
                        **kwargs) -> np.ndarray:
        """Apply baseline correction optimized for FTIR"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        intensity = self.spectrum.intensity
        x = self.spectrum.wavenumber
        
        if method == BaselineMethod.ASYMMETRIC_LEAST_SQUARES:
            # Optimized parameters for FTIR
            lam = kwargs.get('lambda', 1e7)
            p = kwargs.get('p', 0.001)
            baseline = self._als_baseline_ftir(intensity, lam, p)
        
        elif method == BaselineMethod.RUBBERBAND:
            baseline = self._rubberband_baseline_ftir(x, intensity)
        
        elif method == BaselineMethod.SNIP:
            iterations = kwargs.get('iterations', 40)
            baseline = self._snip_baseline(intensity, iterations)
        
        else:
            # Fall back to polynomial
            baseline = self._polynomial_baseline_ftir(x, intensity)
        
        self.spectrum.baseline = baseline
        self.spectrum.corrected_intensity = intensity - baseline
        
        return self.spectrum.corrected_intensity
    
    def _als_baseline_ftir(self, y: np.ndarray, lam: float, p: float, niter: int = 10) -> np.ndarray:
        """Asymmetric least squares optimized for FTIR"""
        from scipy import sparse
        from scipy.sparse.linalg import spsolve
        
        L = len(y)
        D = sparse.diags([1, -2, 1], [0, -1, -2], shape=(L, L-2))
        D = lam * D.dot(D.T)
        w = np.ones(L)
        W = sparse.spdiags(w, 0, L, L)
        
        for _ in range(niter):
            W.setdiag(w)
            Z = W + D
            z = spsolve(Z, w * y)
            w = p * (y > z) + (1 - p) * (y < z)
        
        return z
    
    def _snip_baseline(self, y: np.ndarray, iterations: int) -> np.ndarray:
        """Statistics-sensitive Non-linear Iterative Peak-clipping"""
        baseline = np.copy(y)
        
        for i in range(iterations, 0, -1):
            for j in range(i, len(baseline) - i):
                val = (baseline[j - i] + baseline[j + i]) / 2
                if val < baseline[j]:
                    baseline[j] = val
        
        return baseline
    
    def _polynomial_baseline_ftir(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Polynomial baseline for FTIR"""
        # Select baseline points (regions without peaks)
        baseline_regions = [
            (3800, 4000),  # High wavenumber
            (2700, 2800),  # Between C-H and O-H
            (2000, 2100),  # Typically empty
            (800, 900),    # Low absorption
            (400, 500)     # Low wavenumber
        ]
        
        baseline_points = []
        for start, end in baseline_regions:
            mask = (x >= start) & (x <= end)
            if np.any(mask):
                idx = np.where(mask)[0]
                # Take minimum in region
                min_idx = idx[np.argmin(y[idx])]
                baseline_points.append(min_idx)
        
        if len(baseline_points) < 3:
            # Fall back to percentile method
            baseline_points = np.where(y < np.percentile(y, 10))[0]
        
        # Fit polynomial
        coef = np.polyfit(x[baseline_points], y[baseline_points], 3)
        return np.polyval(coef, x)
    
    def _rubberband_baseline_ftir(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Rubberband baseline for FTIR"""
        # Similar to UV-Vis but optimized for FTIR
        from scipy.spatial import ConvexHull
        
        # Reverse x-axis for proper convex hull
        points = np.column_stack((-x, y))
        
        try:
            hull = ConvexHull(points)
            
            # Get lower hull
            lower_hull_idx = []
            for simplex in hull.simplices:
                if all(points[simplex, 1] <= np.median(y)):
                    lower_hull_idx.extend(simplex)
            
            lower_hull_idx = sorted(set(lower_hull_idx))
            
            if len(lower_hull_idx) > 2:
                # Interpolate baseline
                baseline_func = interpolate.interp1d(
                    x[lower_hull_idx], y[lower_hull_idx],
                    kind='linear', fill_value='extrapolate'
                )
                return baseline_func(x)
        except:
            pass
        
        # Fallback to linear baseline
        return np.linspace(y[0], y[-1], len(y))
    
    def detect_peaks(self, min_height: Optional[float] = None,
                     min_distance: int = 5, prominence: float = 0.05) -> List[Dict]:
        """Detect peaks in FTIR spectrum"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Use corrected intensity if available
        intensity = (self.spectrum.corrected_intensity 
                    if self.spectrum.corrected_intensity is not None 
                    else self.spectrum.intensity)
        
        # For FTIR, we often look for valleys in transmittance
        if self.spectrum.spectrum_type == SpectrumType.TRANSMITTANCE:
            # Invert to find minima as peaks
            intensity = -intensity
        
        # Find peaks
        peaks, properties = signal.find_peaks(
            intensity,
            height=min_height,
            distance=min_distance,
            prominence=prominence,
            width=(1, 50)  # Typical peak width in wavenumbers
        )
        
        # Compile peak information
        peak_list = []
        for i, peak_idx in enumerate(peaks):
            peak_info = {
                'index': int(peak_idx),
                'wavenumber': float(self.spectrum.wavenumber[peak_idx]),
                'intensity': float(abs(intensity[peak_idx])),
                'prominence': float(properties['prominences'][i]),
                'width': float(properties['widths'][i]),
                'fwhm_cm': float(properties['widths'][i])
            }
            
            # Check for functional group assignment
            peak_info['possible_groups'] = self._identify_functional_group(
                peak_info['wavenumber']
            )
            
            peak_list.append(peak_info)
        
        self.spectrum.peaks = peak_list
        return peak_list
    
    def _identify_functional_group(self, wavenumber: float, tolerance: float = 10) -> List[str]:
        """Identify possible functional groups for a peak"""
        possible_groups = []
        
        for group_name, group_info in self.functional_groups.items():
            range_min, range_max = group_info['range']
            if (wavenumber >= range_min - tolerance and 
                wavenumber <= range_max + tolerance):
                possible_groups.append(group_name)
        
        return possible_groups
    
    def fit_peak(self, wavenumber_center: float, window: float = 50,
                 peak_shape: PeakShape = PeakShape.VOIGT) -> Dict[str, Any]:
        """Fit a single peak with specified shape"""
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Select region around peak
        mask = (abs(self.spectrum.wavenumber - wavenumber_center) <= window)
        x = self.spectrum.wavenumber[mask]
        y = self.spectrum.intensity[mask]
        
        if len(x) < 5:
            return {'error': 'Insufficient data points'}
        
        # Initial parameters
        p0 = [
            np.max(y) - np.min(y),  # amplitude
            wavenumber_center,       # center
            window / 4,              # width
            np.min(y)               # baseline
        ]
        
        try:
            if peak_shape == PeakShape.GAUSSIAN:
                popt, pcov = optimize.curve_fit(self._gaussian, x, y, p0=p0)
                y_fit = self._gaussian(x, *popt)
            
            elif peak_shape == PeakShape.LORENTZIAN:
                popt, pcov = optimize.curve_fit(self._lorentzian, x, y, p0=p0)
                y_fit = self._lorentzian(x, *popt)
            
            elif peak_shape == PeakShape.VOIGT:
                # Add shape parameter
                p0.append(0.5)
                popt, pcov = optimize.curve_fit(self._voigt, x, y, p0=p0)
                y_fit = self._voigt(x, *popt)
            
            else:
                return {'error': f'Unsupported peak shape: {peak_shape}'}
            
            # Calculate metrics
            residuals = y - y_fit
            ss_res = np.sum(residuals**2)
            ss_tot = np.sum((y - np.mean(y))**2)
            r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
            
            # Calculate area under peak
            area = np.trapz(y_fit - popt[-1], x)
            
            return {
                'peak_shape': peak_shape.value,
                'parameters': {
                    'amplitude': float(popt[0]),
                    'center': float(popt[1]),
                    'width': float(popt[2]),
                    'baseline': float(popt[-1]),
                    'shape_param': float(popt[3]) if len(popt) > 4 else None
                },
                'area': area,
                'r_squared': r_squared,
                'fit_x': x.tolist(),
                'fit_y': y_fit.tolist()
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _gaussian(self, x, amplitude, center, width, baseline):
        """Gaussian peak function"""
        return amplitude * np.exp(-0.5 * ((x - center) / width)**2) + baseline
    
    def _lorentzian(self, x, amplitude, center, width, baseline):
        """Lorentzian peak function"""
        return amplitude * width**2 / ((x - center)**2 + width**2) + baseline
    
    def _voigt(self, x, amplitude, center, sigma, gamma, baseline):
        """Voigt peak function (convolution of Gaussian and Lorentzian)"""
        z = ((x - center) + 1j * gamma) / (sigma * np.sqrt(2))
        profile = np.real(wofz(z)) / (sigma * np.sqrt(2 * np.pi))
        return amplitude * profile + baseline
    
    def identify_material(self, reference_spectra: Dict[str, np.ndarray],
                          correlation_threshold: float = 0.9) -> List[Dict]:
        """
        Match spectrum against reference library
        
        Args:
            reference_spectra: Dict of {material_name: intensity_array}
            correlation_threshold: Minimum correlation for match
        """
        if self.spectrum is None:
            raise ValueError("No spectrum loaded")
        
        # Use corrected intensity if available
        sample = (self.spectrum.corrected_intensity 
                 if self.spectrum.corrected_intensity is not None 
                 else self.spectrum.intensity)
        
        matches = []
        
        for material_name, reference in reference_spectra.items():
            # Ensure same length (interpolate if needed)
            if len(reference) != len(sample):
                f = interpolate.interp1d(
                    np.linspace(0, 1, len(reference)),
                    reference,
                    kind='linear'
                )
                reference_interp = f(np.linspace(0, 1, len(sample)))
            else:
                reference_interp = reference
            
            # Calculate correlation
            correlation = np.corrcoef(sample, reference_interp)[0, 1]
            
            # Calculate spectral angle
            dot_product = np.dot(sample, reference_interp)
            norms = np.linalg.norm(sample) * np.linalg.norm(reference_interp)
            spectral_angle = np.arccos(np.clip(dot_product / norms, -1, 1))
            
            if correlation >= correlation_threshold:
                matches.append({
                    'material': material_name,
                    'correlation': float(correlation),
                    'spectral_angle_rad': float(spectral_angle),
                    'confidence': float(correlation * (1 - spectral_angle / np.pi))
                })
        
        # Sort by confidence
        matches.sort(key=lambda x: x['confidence'], reverse=True)
        
        return matches

# ============================================================================
# Test Data Generators
# ============================================================================

class OpticalTestDataGenerator:
    """Generate realistic test data for optical spectroscopy"""
    
    @staticmethod
    def generate_uv_vis_spectrum(material_type: str = 'silicon',
                                 noise_level: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
        """Generate UV-Vis-NIR test spectrum"""
        wavelength = np.linspace(200, 2500, 1000)
        
        if material_type == 'silicon':
            # Silicon absorption edge around 1100 nm
            eg = 1.12  # eV
            lambda_g = 1239.84 / eg  # nm
            
            # Absorption coefficient
            alpha = np.zeros_like(wavelength)
            mask = wavelength < lambda_g
            energy = 1239.84 / wavelength[mask]
            alpha[mask] = 1e4 * np.sqrt(energy - eg) / energy
            
            # Add Urbach tail
            alpha[mask] += 100 * np.exp((energy - eg) / 0.05)
            
            # Convert to transmittance (assuming 500 um thickness)
            thickness = 0.05  # cm
            transmittance = np.exp(-alpha * thickness)
            
        elif material_type == 'gaas':
            # GaAs direct band gap at 1.42 eV
            eg = 1.42
            lambda_g = 1239.84 / eg
            
            alpha = np.zeros_like(wavelength)
            mask = wavelength < lambda_g
            energy = 1239.84 / wavelength[mask]
            alpha[mask] = 5e4 * (energy - eg)**2 / energy
            
            thickness = 0.001  # cm
            transmittance = np.exp(-alpha * thickness)
            
        elif material_type == 'thin_film':
            # Thin film with interference fringes
            n = 2.5  # refractive index
            d = 500  # nm thickness
            
            # Calculate optical path difference
            phase = 4 * np.pi * n * d / wavelength
            
            # Fresnel coefficients
            r = (n - 1) / (n + 1)
            t = 2 / (n + 1)
            
            # Multiple beam interference
            transmittance = t**2 / (1 + r**2 - 2*r*np.cos(phase))
            
        else:
            # Default: broad absorption peak
            center = 600  # nm
            width = 100
            transmittance = 1 - 0.8 * np.exp(-((wavelength - center) / width)**2)
        
        # Add noise
        if noise_level > 0:
            transmittance += np.random.normal(0, noise_level, len(transmittance))
            transmittance = np.clip(transmittance, 0, 1)
        
        return wavelength, transmittance
    
    @staticmethod
    def generate_ftir_spectrum(material_type: str = 'polymer',
                              noise_level: float = 0.005) -> Tuple[np.ndarray, np.ndarray]:
        """Generate FTIR test spectrum"""
        wavenumber = np.linspace(400, 4000, 3600)
        transmittance = np.ones_like(wavenumber) * 100  # Start at 100% T
        
        if material_type == 'polymer':
            # Polystyrene peaks
            peaks = [
                (3026, 20, 15),  # C-H aromatic stretch
                (2924, 30, 20),  # C-H aliphatic stretch
                (1601, 40, 10),  # C=C aromatic stretch
                (1493, 45, 10),  # C=C aromatic stretch
                (1452, 35, 15),  # C-H bend
                (1028, 50, 20),  # C-H in-plane bend
                (906, 60, 15),   # C-H out-of-plane bend
                (698, 70, 20),   # C-H out-of-plane bend
            ]
            
            for center, depth, width in peaks:
                transmittance -= depth * np.exp(-((wavenumber - center) / width)**2)
        
        elif material_type == 'protein':
            # Protein amide bands
            peaks = [
                (3300, 40, 100), # N-H/O-H stretch (broad)
                (1650, 60, 30),  # Amide I (C=O stretch)
                (1540, 45, 25),  # Amide II (N-H bend)
                (1240, 30, 30),  # Amide III
            ]
            
            for center, depth, width in peaks:
                transmittance -= depth * np.exp(-((wavenumber - center) / width)**2)
        
        elif material_type == 'silicon_oxide':
            # SiO2 peaks
            transmittance -= 80 * np.exp(-((wavenumber - 1075) / 100)**2)  # Si-O stretch
            transmittance -= 40 * np.exp(-((wavenumber - 800) / 50)**2)   # Si-O bend
            transmittance -= 30 * np.exp(-((wavenumber - 450) / 40)**2)   # Si-O rock
        
        else:
            # Default: multiple peaks
            for _ in range(5):
                center = np.random.uniform(600, 3500)
                depth = np.random.uniform(20, 60)
                width = np.random.uniform(20, 100)
                transmittance -= depth * np.exp(-((wavenumber - center) / width)**2)
        
        # Add baseline drift
        baseline_drift = 5 * np.sin(2 * np.pi * wavenumber / 2000)
        transmittance += baseline_drift
        
        # Add noise
        if noise_level > 0:
            transmittance += np.random.normal(0, noise_level * 100, len(transmittance))
        
        # Ensure realistic bounds
        transmittance = np.clip(transmittance, 0, 100)
        
        return wavenumber, transmittance

# ============================================================================
# Quality Control Module
# ============================================================================

class SpectroscopyQC:
    """Quality control checks for spectroscopy data"""
    
    @staticmethod
    def check_signal_to_noise(spectrum: np.ndarray, 
                              baseline_region: Optional[Tuple[int, int]] = None) -> float:
        """Calculate signal-to-noise ratio"""
        if baseline_region is None:
            # Use last 10% of spectrum as baseline
            baseline_region = (int(len(spectrum) * 0.9), len(spectrum))
        
        noise = np.std(spectrum[baseline_region[0]:baseline_region[1]])
        signal = np.max(spectrum) - np.mean(spectrum[baseline_region[0]:baseline_region[1]])
        
        return signal / noise if noise > 0 else np.inf
    
    @staticmethod
    def check_saturation(spectrum: np.ndarray, threshold: float = 0.95) -> Dict[str, Any]:
        """Check for detector saturation"""
        max_val = np.max(spectrum)
        saturated_points = np.sum(spectrum > threshold * max_val)
        
        return {
            'is_saturated': saturated_points > 10,
            'saturated_points': int(saturated_points),
            'saturation_percentage': float(100 * saturated_points / len(spectrum))
        }
    
    @staticmethod
    def check_spectral_range(wavelength: np.ndarray, 
                             expected_range: Tuple[float, float]) -> Dict[str, Any]:
        """Verify spectral range coverage"""
        actual_range = (np.min(wavelength), np.max(wavelength))
        
        return {
            'actual_range': actual_range,
            'expected_range': expected_range,
            'range_ok': (actual_range[0] <= expected_range[0] and 
                        actual_range[1] >= expected_range[1]),
            'coverage_percentage': float(100 * (actual_range[1] - actual_range[0]) / 
                                        (expected_range[1] - expected_range[0]))
        }
    
    @staticmethod
    def validate_measurement(spectrum_data: Dict[str, Any]) -> Dict[str, Any]:
        """Comprehensive measurement validation"""
        results = {
            'valid': True,
            'warnings': [],
            'errors': []
        }
        
        # Check for required fields
        required_fields = ['wavelength', 'intensity', 'spectrum_type']
        for field in required_fields:
            if field not in spectrum_data:
                results['errors'].append(f"Missing required field: {field}")
                results['valid'] = False
        
        if not results['valid']:
            return results
        
        # Check data consistency
        if len(spectrum_data['wavelength']) != len(spectrum_data['intensity']):
            results['errors'].append("Wavelength and intensity arrays have different lengths")
            results['valid'] = False
        
        # Check for NaN or Inf values
        if np.any(np.isnan(spectrum_data['intensity'])) or np.any(np.isinf(spectrum_data['intensity'])):
            results['warnings'].append("Spectrum contains NaN or Inf values")
        
        # Check monotonicity of wavelength/wavenumber
        diff = np.diff(spectrum_data['wavelength'])
        if not (np.all(diff > 0) or np.all(diff < 0)):
            results['warnings'].append("Wavelength array is not monotonic")
        
        # Check intensity range
        if np.min(spectrum_data['intensity']) < 0:
            results['warnings'].append("Negative intensity values detected")
        
        return results

# ============================================================================
# Integration Functions
# ============================================================================

def process_uv_vis_measurement(wavelength: np.ndarray, intensity: np.ndarray,
                               spectrum_type: str = 'transmission',
                               calculate_band_gap: bool = True,
                               band_gap_type: str = 'direct_allowed',
                               baseline_correction: bool = True) -> Dict[str, Any]:
    """
    Complete UV-Vis-NIR processing pipeline
    """
    # Initialize analyzer
    analyzer = UVVisNIRAnalyzer()
    
    # Load spectrum
    spectrum = analyzer.load_spectrum(
        wavelength=wavelength,
        intensity=intensity,
        spectrum_type=SpectrumType(spectrum_type)
    )
    
    # Baseline correction
    if baseline_correction:
        analyzer.correct_baseline(BaselineMethod.ASYMMETRIC_LEAST_SQUARES)
    
    # Peak detection
    peaks = analyzer.detect_peaks()
    
    # Band gap calculation
    band_gap = None
    if calculate_band_gap:
        band_gap = analyzer.calculate_band_gap(BandGapType(band_gap_type))
    
    # Check for interference fringes
    interference = analyzer.analyze_interference()
    
    # Quality control
    qc = SpectroscopyQC()
    snr = qc.check_signal_to_noise(spectrum.intensity)
    saturation = qc.check_saturation(spectrum.intensity)
    
    return {
        'spectrum': {
            'wavelength': spectrum.wavelength.tolist(),
            'intensity': spectrum.intensity.tolist(),
            'corrected_intensity': spectrum.corrected_intensity.tolist() if spectrum.corrected_intensity is not None else None,
            'baseline': spectrum.baseline.tolist() if spectrum.baseline is not None else None,
            'energy_ev': spectrum.energy.tolist(),
            'wavenumber': spectrum.wavenumber.tolist()
        },
        'peaks': peaks,
        'band_gap': band_gap,
        'interference': interference,
        'quality_metrics': {
            'signal_to_noise': snr,
            'saturation': saturation
        }
    }

def process_ftir_measurement(wavenumber: np.ndarray, intensity: np.ndarray,
                             spectrum_type: str = 'transmittance',
                             baseline_correction: bool = True,
                             identify_functional_groups: bool = True) -> Dict[str, Any]:
    """
    Complete FTIR processing pipeline
    """
    # Initialize analyzer
    analyzer = FTIRAnalyzer()
    
    # Load spectrum
    spectrum = analyzer.load_spectrum(
        wavenumber=wavenumber,
        intensity=intensity,
        spectrum_type=SpectrumType(spectrum_type)
    )
    
    # Baseline correction
    if baseline_correction:
        analyzer.correct_baseline(BaselineMethod.ASYMMETRIC_LEAST_SQUARES)
    
    # Convert to absorbance for peak detection
    absorbance = analyzer.convert_to_absorbance()
    
    # Peak detection
    peaks = analyzer.detect_peaks()
    
    # Quality control
    qc = SpectroscopyQC()
    snr = qc.check_signal_to_noise(spectrum.intensity)
    
    return {
        'spectrum': {
            'wavenumber': spectrum.wavenumber.tolist(),
            'intensity': spectrum.intensity.tolist(),
            'corrected_intensity': spectrum.corrected_intensity.tolist() if spectrum.corrected_intensity is not None else None,
            'baseline': spectrum.baseline.tolist() if spectrum.baseline is not None else None,
            'absorbance': absorbance.tolist()
        },
        'peaks': peaks,
        'quality_metrics': {
            'signal_to_noise': snr
        }
    }

# ============================================================================
# Main execution for testing
# ============================================================================

if __name__ == "__main__":
    print("Session 7: Optical I - Analysis Modules")
    print("=" * 50)
    
    # Test UV-Vis-NIR
    print("\n1. UV-Vis-NIR Analysis Test")
    print("-" * 30)
    
    generator = OpticalTestDataGenerator()
    wavelength, transmittance = generator.generate_uv_vis_spectrum('silicon')
    
    results = process_uv_vis_measurement(
        wavelength=wavelength,
        intensity=transmittance,
        spectrum_type='transmission',
        calculate_band_gap=True,
        band_gap_type='indirect_allowed'
    )
    
    print(f"Peaks detected: {len(results['peaks'])}")
    if results['band_gap']:
        print(f"Band gap: {results['band_gap']['value_ev']:.3f} eV")
    print(f"Signal-to-noise ratio: {results['quality_metrics']['signal_to_noise']:.1f}")
    
    # Test FTIR
    print("\n2. FTIR Analysis Test")
    print("-" * 30)
    
    wavenumber, transmittance = generator.generate_ftir_spectrum('polymer')
    
    results = process_ftir_measurement(
        wavenumber=wavenumber,
        intensity=transmittance,
        spectrum_type='transmittance'
    )
    
    print(f"Peaks detected: {len(results['peaks'])}")
    if results['peaks']:
        print("Top 5 peaks:")
        for peak in results['peaks'][:5]:
            print(f"  {peak['wavenumber']:.1f} cm⁻¹: {peak.get('possible_groups', [])}")
    
    print("\n✅ Session 7 Backend Modules Ready!")
