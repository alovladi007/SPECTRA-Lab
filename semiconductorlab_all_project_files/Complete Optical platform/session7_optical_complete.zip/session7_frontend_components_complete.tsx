// frontend/Session7OpticalComponents.tsx (continued)
// Completing FTIR Interface and Adding Spectral Viewer Component

                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>

                      <div className="p-4 border rounded">
                        <h4 className="font-semibold mb-2">C-H Region (2850-3000 cm⁻¹)</h4>
                        {peaks.filter(p => p.wavenumber! >= 2850 && p.wavenumber! <= 3000).length > 0 ? (
                          <ul className="space-y-1">
                            {peaks
                              .filter(p => p.wavenumber! >= 2850 && p.wavenumber! <= 3000)
                              .map((peak, i) => (
                                <li key={i} className="text-sm">
                                  {peak.wavenumber} cm⁻¹: {peak.possibleGroups?.join(', ')}
                                </li>
                              ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>

                      <div className="p-4 border rounded">
                        <h4 className="font-semibold mb-2">C≡N / C≡C Region (2100-2260 cm⁻¹)</h4>
                        {peaks.filter(p => p.wavenumber! >= 2100 && p.wavenumber! <= 2260).length > 0 ? (
                          <ul className="space-y-1">
                            {peaks
                              .filter(p => p.wavenumber! >= 2100 && p.wavenumber! <= 2260)
                              .map((peak, i) => (
                                <li key={i} className="text-sm">
                                  {peak.wavenumber} cm⁻¹: {peak.possibleGroups?.join(', ')}
                                </li>
                              ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>

                      <div className="p-4 border rounded">
                        <h4 className="font-semibold mb-2">C=O Region (1670-1780 cm⁻¹)</h4>
                        {peaks.filter(p => p.wavenumber! >= 1670 && p.wavenumber! <= 1780).length > 0 ? (
                          <ul className="space-y-1">
                            {peaks
                              .filter(p => p.wavenumber! >= 1670 && p.wavenumber! <= 1780)
                              .map((peak, i) => (
                                <li key={i} className="text-sm">
                                  {peak.wavenumber} cm⁻¹: {peak.possibleGroups?.join(', ')}
                                </li>
                              ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>

                      <div className="p-4 border rounded">
                        <h4 className="font-semibold mb-2">C=C / Aromatic (1450-1600 cm⁻¹)</h4>
                        {peaks.filter(p => p.wavenumber! >= 1450 && p.wavenumber! <= 1600).length > 0 ? (
                          <ul className="space-y-1">
                            {peaks
                              .filter(p => p.wavenumber! >= 1450 && p.wavenumber! <= 1600)
                              .map((peak, i) => (
                                <li key={i} className="text-sm">
                                  {peak.wavenumber} cm⁻¹: {peak.possibleGroups?.join(', ')}
                                </li>
                              ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>

                      <div className="p-4 border rounded">
                        <h4 className="font-semibold mb-2">Fingerprint (600-1400 cm⁻¹)</h4>
                        {peaks.filter(p => p.wavenumber! >= 600 && p.wavenumber! <= 1400).length > 0 ? (
                          <ul className="space-y-1">
                            {peaks
                              .filter(p => p.wavenumber! >= 600 && p.wavenumber! <= 1400)
                              .map((peak, i) => (
                                <li key={i} className="text-sm">
                                  {peak.wavenumber} cm⁻¹: {peak.possibleGroups?.join(', ')}
                                </li>
                              ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-gray-500">No peaks in this region</p>
                        )}
                      </div>
                    </div>

                    {/* Summary */}
                    <Card className="bg-gray-50">
                      <CardContent className="pt-6">
                        <h4 className="font-semibold mb-2">Compound Classification</h4>
                        <div className="flex flex-wrap gap-2">
                          {peaks.some(p => p.possibleGroups?.some(g => g.includes('aromatic'))) && (
                            <Badge>Aromatic</Badge>
                          )}
                          {peaks.some(p => p.possibleGroups?.some(g => g.includes('C=O'))) && (
                            <Badge>Carbonyl</Badge>
                          )}
                          {peaks.some(p => p.possibleGroups?.some(g => g.includes('O-H'))) && (
                            <Badge>Hydroxyl</Badge>
                          )}
                          {peaks.some(p => p.possibleGroups?.some(g => g.includes('N-H'))) && (
                            <Badge>Amine</Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Library match button */}
                    <Button className="w-full">
                      <Search className="mr-2 h-4 w-4" />
                      Search Spectral Library
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// Universal Spectral Viewer Component
// ============================================================================

interface SpectralViewerProps {
  data: SpectrumData;
  xAxis: 'wavelength' | 'wavenumber' | 'energy';
  yAxis: 'intensity' | 'absorbance' | 'transmittance';
  showPeaks?: boolean;
  showBaseline?: boolean;
  showGrid?: boolean;
  interactive?: boolean;
  height?: number;
  onPointClick?: (point: any) => void;
  onRangeSelect?: (range: [number, number]) => void;
}

export const SpectralViewer: React.FC<SpectralViewerProps> = ({
  data,
  xAxis = 'wavelength',
  yAxis = 'intensity',
  showPeaks = true,
  showBaseline = false,
  showGrid = true,
  interactive = true,
  height = 400,
  onPointClick,
  onRangeSelect
}) => {
  const [selectedRange, setSelectedRange] = useState<[number, number] | null>(null);
  const [zoomDomain, setZoomDomain] = useState<{ x: [number, number] | null, y: [number, number] | null }>({
    x: null,
    y: null
  });
  const [hoveredPoint, setHoveredPoint] = useState<any>(null);

  // Prepare chart data based on selected axes
  const chartData = useMemo(() => {
    const xData = data[xAxis as keyof SpectrumData] as number[];
    const yData = data[yAxis as keyof SpectrumData] as number[] || data.intensity;

    if (!xData || !yData) return [];

    return xData.map((x, i) => ({
      x: x,
      y: yData[i],
      baseline: data.baseline?.[i],
      corrected: data.correctedIntensity?.[i]
    }));
  }, [data, xAxis, yAxis]);

  // Handle zoom
  const handleZoom = useCallback((domain: any) => {
    if (domain) {
      setZoomDomain({
        x: [domain.startX, domain.endX],
        y: [domain.startY, domain.endY]
      });
    }
  }, []);

  // Reset zoom
  const resetZoom = () => {
    setZoomDomain({ x: null, y: null });
  };

  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-lg">
          <p className="text-sm font-semibold">{`${xAxis}: ${label?.toFixed(2)}`}</p>
          <p className="text-sm">{`${yAxis}: ${payload[0]?.value?.toFixed(4)}`}</p>
          {showBaseline && payload[1] && (
            <p className="text-sm text-gray-500">{`Baseline: ${payload[1]?.value?.toFixed(4)}`}</p>
          )}
        </div>
      );
    }
    return null;
  };

  // Get axis labels
  const getXAxisLabel = () => {
    switch (xAxis) {
      case 'wavelength': return 'Wavelength (nm)';
      case 'wavenumber': return 'Wavenumber (cm⁻¹)';
      case 'energy': return 'Energy (eV)';
      default: return '';
    }
  };

  const getYAxisLabel = () => {
    switch (yAxis) {
      case 'intensity': return 'Intensity';
      case 'absorbance': return 'Absorbance';
      case 'transmittance': return 'Transmittance (%)';
      default: return '';
    }
  };

  return (
    <div className="relative">
      {/* Toolbar */}
      <div className="absolute top-2 right-2 z-10 flex gap-2">
        <Button size="sm" variant="outline" onClick={resetZoom}>
          <RefreshCw className="h-4 w-4" />
        </Button>
        <Button size="sm" variant="outline">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button size="sm" variant="outline">
          <ZoomOut className="h-4 w-4" />
        </Button>
      </div>

      <ResponsiveContainer width="100%" height={height}>
        <LineChart 
          data={chartData}
          margin={{ top: 5, right: 30, left: 20, bottom: 50 }}
          onMouseMove={(e: any) => {
            if (e && e.activePayload) {
              setHoveredPoint(e.activePayload[0]);
            }
          }}
          onMouseLeave={() => setHoveredPoint(null)}
        >
          {showGrid && <CartesianGrid strokeDasharray="3 3" opacity={0.3} />}
          
          <XAxis 
            dataKey="x"
            type="number"
            domain={zoomDomain.x || 'auto'}
            reversed={xAxis === 'wavenumber'}
            label={{ 
              value: getXAxisLabel(), 
              position: 'insideBottom', 
              offset: -10,
              style: { textAnchor: 'middle' }
            }}
          />
          
          <YAxis 
            domain={zoomDomain.y || 'auto'}
            label={{ 
              value: getYAxisLabel(), 
              angle: -90, 
              position: 'insideLeft',
              style: { textAnchor: 'middle' }
            }}
          />
          
          {interactive && <Tooltip content={<CustomTooltip />} />}
          
          <Line
            type="monotone"
            dataKey="y"
            stroke="#8884d8"
            strokeWidth={1.5}
            dot={false}
            activeDot={interactive ? { r: 6 } : false}
          />
          
          {showBaseline && data.baseline && (
            <Line
              type="monotone"
              dataKey="baseline"
              stroke="#ff7300"
              strokeWidth={1}
              strokeDasharray="5 5"
              dot={false}
            />
          )}
          
          {data.correctedIntensity && (
            <Line
              type="monotone"
              dataKey="corrected"
              stroke="#82ca9d"
              strokeWidth={1.5}
              dot={false}
            />
          )}
          
          {interactive && (
            <Brush 
              dataKey="x" 
              height={30} 
              stroke="#8884d8"
              onChange={(e: any) => {
                if (onRangeSelect && e.startIndex !== undefined && e.endIndex !== undefined) {
                  const start = chartData[e.startIndex].x;
                  const end = chartData[e.endIndex].x;
                  onRangeSelect([start, end]);
                }
              }}
            />
          )}
        </LineChart>
      </ResponsiveContainer>

      {/* Status bar */}
      {hoveredPoint && (
        <div className="absolute bottom-0 left-0 bg-white/90 px-2 py-1 text-xs">
          {xAxis}: {hoveredPoint.payload.x.toFixed(2)}, {yAxis}: {hoveredPoint.payload.y.toFixed(4)}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// Batch Processing Component
// ============================================================================

interface BatchSample {
  id: string;
  name: string;
  status: 'pending' | 'acquiring' | 'processing' | 'complete' | 'error';
  progress: number;
  result?: any;
  error?: string;
}

export const BatchProcessor: React.FC = () => {
  const [samples, setSamples] = useState<BatchSample[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentSampleIndex, setCurrentSampleIndex] = useState(-1);

  const addSample = (name: string) => {
    const newSample: BatchSample = {
      id: `sample_${Date.now()}`,
      name,
      status: 'pending',
      progress: 0
    };
    setSamples([...samples, newSample]);
  };

  const startBatch = async () => {
    setIsRunning(true);
    
    for (let i = 0; i < samples.length; i++) {
      setCurrentSampleIndex(i);
      
      // Update status to acquiring
      setSamples(prev => prev.map((s, idx) => 
        idx === i ? { ...s, status: 'acquiring', progress: 0 } : s
      ));

      // Simulate acquisition
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setSamples(prev => prev.map((s, idx) => 
          idx === i ? { ...s, progress } : s
        ));
      }

      // Update status to processing
      setSamples(prev => prev.map((s, idx) => 
        idx === i ? { ...s, status: 'processing' } : s
      ));

      // Simulate processing
      await new Promise(resolve => setTimeout(resolve, 500));

      // Update status to complete
      setSamples(prev => prev.map((s, idx) => 
        idx === i ? { ...s, status: 'complete', result: { /* mock result */ } } : s
      ));
    }

    setIsRunning(false);
    setCurrentSampleIndex(-1);
  };

  const getStatusIcon = (status: BatchSample['status']) => {
    switch (status) {
      case 'pending': return <AlertCircle className="h-4 w-4 text-gray-400" />;
      case 'acquiring': return <Activity className="h-4 w-4 text-blue-500 animate-pulse" />;
      case 'processing': return <RefreshCw className="h-4 w-4 text-yellow-500 animate-spin" />;
      case 'complete': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Batch Processing</CardTitle>
        <CardDescription>
          Queue multiple samples for automated acquisition and analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Sample list */}
        <div className="space-y-2">
          {samples.map((sample, index) => (
            <div 
              key={sample.id}
              className={`flex items-center justify-between p-3 border rounded ${
                index === currentSampleIndex ? 'bg-blue-50 border-blue-300' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                {getStatusIcon(sample.status)}
                <span className="font-medium">{sample.name}</span>
              </div>
              <div className="flex items-center gap-3">
                {sample.status === 'acquiring' && (
                  <div className="w-32">
                    <Progress value={sample.progress} className="h-2" />
                  </div>
                )}
                <Badge variant={sample.status === 'complete' ? 'success' : 'default'}>
                  {sample.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const name = prompt('Enter sample name:');
              if (name) addSample(name);
            }}
            disabled={isRunning}
          >
            Add Sample
          </Button>
          <Button
            onClick={startBatch}
            disabled={isRunning || samples.length === 0}
          >
            {isRunning ? 'Running...' : 'Start Batch'}
          </Button>
        </div>

        {/* Summary */}
        {samples.length > 0 && (
          <div className="mt-4 p-3 bg-gray-50 rounded">
            <div className="grid grid-cols-4 gap-2 text-sm">
              <div>
                <span className="text-gray-500">Total:</span> {samples.length}
              </div>
              <div>
                <span className="text-gray-500">Pending:</span> {samples.filter(s => s.status === 'pending').length}
              </div>
              <div>
                <span className="text-gray-500">Complete:</span> {samples.filter(s => s.status === 'complete').length}
              </div>
              <div>
                <span className="text-gray-500">Errors:</span> {samples.filter(s => s.status === 'error').length}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// ============================================================================
// Export all components
// ============================================================================

export default {
  UVVisNIRInterface,
  FTIRInterface,
  SpectralViewer,
  BatchProcessor
};
