# tests/test_session7_optical.py
"""
Session 7: Comprehensive Test Suite for UV-Vis-NIR and FTIR Analysis
Unit tests, integration tests, and performance benchmarks
"""

import pytest
import numpy as np
import pandas as pd
from unittest.mock import Mock, patch, MagicMock
import json
import time
from datetime import datetime
from typing import Dict, List, Any

# Import modules to test (assuming proper package structure)
import sys
sys.path.append('../backend')

from optical_analysis_session7 import (
    UVVisNIRAnalyzer,
    FTIRAnalyzer,
    OpticalSpectrum,
    FTIRSpectrum,
    OpticalTestDataGenerator,
    SpectroscopyQC,
    SpectrumType,
    BandGapType,
    BaselineMethod,
    PeakShape,
    process_uv_vis_measurement,
    process_ftir_measurement
)

# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def silicon_spectrum():
    """Generate silicon UV-Vis spectrum test data"""
    generator = OpticalTestDataGenerator()
    wavelength, transmittance = generator.generate_uv_vis_spectrum('silicon')
    return wavelength, transmittance

@pytest.fixture
def polymer_ftir_spectrum():
    """Generate polymer FTIR spectrum test data"""
    generator = OpticalTestDataGenerator()
    wavenumber, transmittance = generator.generate_ftir_spectrum('polymer')
    return wavenumber, transmittance

@pytest.fixture
def uv_vis_analyzer():
    """Create UV-Vis-NIR analyzer instance"""
    return UVVisNIRAnalyzer()

@pytest.fixture
def ftir_analyzer():
    """Create FTIR analyzer instance"""
    return FTIRAnalyzer()

# ============================================================================
# UV-Vis-NIR Analyzer Tests
# ============================================================================

class TestUVVisNIRAnalyzer:
    """Test suite for UV-Vis-NIR analyzer"""
    
    def test_spectrum_loading(self, uv_vis_analyzer, silicon_spectrum):
        """Test spectrum data loading and property calculation"""
        wavelength, intensity = silicon_spectrum
        
        spectrum = uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=intensity,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        assert spectrum is not None
        assert len(spectrum.wavelength) == len(intensity)
        assert spectrum.spectrum_type == SpectrumType.TRANSMISSION
        assert spectrum.energy is not None
        assert spectrum.wavenumber is not None
        
        # Check energy calculation (E = hc/λ)
        expected_energy = 1239.84 / wavelength[0]  # eV
        np.testing.assert_allclose(spectrum.energy[0], expected_energy, rtol=1e-5)
    
    def test_spectrum_type_conversion(self, uv_vis_analyzer, silicon_spectrum):
        """Test conversion between transmission, absorption, reflectance"""
        wavelength, transmittance = silicon_spectrum
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        # Convert to absorption
        absorption = uv_vis_analyzer.convert_spectrum_type(SpectrumType.ABSORPTION)
        expected_absorption = -np.log10(transmittance)
        np.testing.assert_allclose(absorption, expected_absorption, rtol=1e-5)
        
        # Convert to reflectance (approximate)
        reflectance = uv_vis_analyzer.convert_spectrum_type(SpectrumType.REFLECTANCE)
        assert np.all(reflectance >= 0) and np.all(reflectance <= 1)
    
    def test_baseline_correction_methods(self, uv_vis_analyzer, silicon_spectrum):
        """Test different baseline correction methods"""
        wavelength, intensity = silicon_spectrum
        
        # Add artificial baseline drift
        baseline_drift = 0.1 * np.sin(2 * np.pi * wavelength / 1000)
        intensity_with_drift = intensity + baseline_drift
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=intensity_with_drift,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        # Test polynomial baseline
        corrected_poly = uv_vis_analyzer.correct_baseline(
            method=BaselineMethod.POLYNOMIAL,
            order=3
        )
        assert corrected_poly is not None
        assert len(corrected_poly) == len(intensity)
        
        # Test ALS baseline
        corrected_als = uv_vis_analyzer.correct_baseline(
            method=BaselineMethod.ASYMMETRIC_LEAST_SQUARES,
            lambda_param=1e6,
            p=0.01
        )
        assert corrected_als is not None
        
        # Test rubberband baseline
        corrected_rubber = uv_vis_analyzer.correct_baseline(
            method=BaselineMethod.RUBBERBAND
        )
        assert corrected_rubber is not None
    
    def test_band_gap_calculation(self, uv_vis_analyzer):
        """Test band gap extraction using Tauc plot method"""
        # Create spectrum with known band gap
        wavelength = np.linspace(400, 1400, 500)
        eg = 1.12  # Silicon band gap in eV
        lambda_g = 1239.84 / eg
        
        # Create absorption spectrum
        absorption = np.zeros_like(wavelength)
        mask = wavelength < lambda_g
        energy = 1239.84 / wavelength[mask]
        # Indirect band gap: (αhν)^0.5 = B(hν - Eg)
        absorption[mask] = ((energy - eg) * 1e4)**2 / energy**2
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=absorption,
            spectrum_type=SpectrumType.ABSORPTION
        )
        
        # Calculate band gap
        band_gap_result = uv_vis_analyzer.calculate_band_gap(
            band_gap_type=BandGapType.INDIRECT_ALLOWED,
            energy_range=(1.0, 1.3)
        )
        
        assert band_gap_result is not None
        assert 'value_ev' in band_gap_result
        assert abs(band_gap_result['value_ev'] - eg) < 0.05  # Within 50 meV
        assert band_gap_result['r_squared'] > 0.9
    
    def test_peak_detection(self, uv_vis_analyzer):
        """Test peak detection in spectrum"""
        # Create spectrum with known peaks
        wavelength = np.linspace(300, 800, 500)
        intensity = np.ones_like(wavelength) * 0.8
        
        # Add Gaussian peaks
        peaks_true = [(400, 0.3, 20), (550, 0.5, 30), (700, 0.4, 25)]
        for center, height, width in peaks_true:
            intensity += height * np.exp(-((wavelength - center) / width)**2)
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=intensity,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        # Detect peaks
        peaks = uv_vis_analyzer.detect_peaks(
            min_height=0.1,
            min_distance=50,
            prominence=0.1
        )
        
        assert len(peaks) >= 3
        
        # Check if detected peaks are close to true peaks
        detected_wavelengths = [p['wavelength'] for p in peaks]
        for true_peak in peaks_true:
            assert any(abs(dw - true_peak[0]) < 30 for dw in detected_wavelengths)
    
    def test_interference_analysis(self, uv_vis_analyzer):
        """Test thin film interference analysis"""
        # Create spectrum with interference fringes
        wavelength = np.linspace(400, 1000, 600)
        n = 2.5  # refractive index
        d = 500  # nm thickness
        
        # Calculate interference pattern
        phase = 4 * np.pi * n * d / wavelength
        r = (n - 1) / (n + 1)
        transmittance = 1 / (1 + r**2 - 2*r*np.cos(phase))
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        # Analyze interference
        result = uv_vis_analyzer.analyze_interference(refractive_index=n)
        
        assert 'thickness_nm' in result
        if 'thickness_nm' in result:
            # Check if calculated thickness is close to true value
            assert abs(result['thickness_nm'] - d) < 50  # Within 50 nm

# ============================================================================
# FTIR Analyzer Tests
# ============================================================================

class TestFTIRAnalyzer:
    """Test suite for FTIR analyzer"""
    
    def test_spectrum_loading(self, ftir_analyzer, polymer_ftir_spectrum):
        """Test FTIR spectrum loading"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        spectrum = ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        assert spectrum is not None
        assert len(spectrum.wavenumber) == len(transmittance)
        assert spectrum.wavelength is not None
        np.testing.assert_allclose(spectrum.wavelength, 1e7 / wavenumber, rtol=1e-5)
    
    def test_interferogram_processing(self, ftir_analyzer):
        """Test interferogram to spectrum conversion"""
        # Create synthetic interferogram
        n_points = 4096
        mirror_position = np.linspace(-1, 1, n_points)  # cm
        
        # Generate interferogram (simplified)
        frequencies = [1000, 1500, 2000]  # cm^-1
        interferogram = np.zeros(n_points)
        for freq in frequencies:
            interferogram += np.cos(2 * np.pi * freq * mirror_position)
        
        # Add center burst
        interferogram += 10 * np.exp(-mirror_position**2 / 0.01)
        
        # Process interferogram
        wavenumber, intensity = ftir_analyzer.process_interferogram(
            interferogram=interferogram,
            mirror_position=mirror_position
        )
        
        assert len(wavenumber) > 0
        assert len(intensity) == len(wavenumber)
        assert np.all(wavenumber >= 400) and np.all(wavenumber <= 4000)
    
    def test_transmittance_to_absorbance(self, ftir_analyzer, polymer_ftir_spectrum):
        """Test conversion from transmittance to absorbance"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        absorbance = ftir_analyzer.convert_to_absorbance()
        
        # Check conversion: A = -log10(T/100)
        expected_absorbance = -np.log10(transmittance / 100)
        np.testing.assert_allclose(absorbance, expected_absorbance, rtol=1e-5)
    
    def test_baseline_correction_ftir(self, ftir_analyzer, polymer_ftir_spectrum):
        """Test FTIR-specific baseline correction"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        # Test ALS baseline
        corrected = ftir_analyzer.correct_baseline(
            method=BaselineMethod.ASYMMETRIC_LEAST_SQUARES,
            lambda_param=1e7,
            p=0.001
        )
        
        assert corrected is not None
        assert len(corrected) == len(transmittance)
        
        # Baseline should be smoother than original
        assert np.std(np.diff(ftir_analyzer.spectrum.baseline)) < np.std(np.diff(transmittance))
    
    def test_peak_detection_ftir(self, ftir_analyzer, polymer_ftir_spectrum):
        """Test peak detection in FTIR spectrum"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        peaks = ftir_analyzer.detect_peaks(
            min_distance=5,
            prominence=0.05
        )
        
        assert len(peaks) > 0
        
        # Check if functional groups are identified
        for peak in peaks:
            assert 'possible_groups' in peak
            assert isinstance(peak['possible_groups'], list)
    
    def test_functional_group_identification(self, ftir_analyzer):
        """Test functional group identification"""
        # Test specific wavenumbers
        test_cases = [
            (3400, ['O-H stretch (alcohol)']),
            (2950, ['C-H stretch (alkane)']),
            (1710, ['C=O stretch (carbonyl)']),
            (1050, ['C-O stretch (alcohol)', 'C-O stretch (ether)']),
        ]
        
        for wavenumber, expected_groups in test_cases:
            groups = ftir_analyzer._identify_functional_group(wavenumber, tolerance=20)
            assert any(eg in expected_groups for eg in groups)
    
    def test_peak_fitting(self, ftir_analyzer):
        """Test single peak fitting with different shapes"""
        # Create synthetic peak
        wavenumber = np.linspace(1650, 1750, 100)
        center = 1700
        width = 10
        amplitude = 50
        
        # Gaussian peak
        transmittance = 100 - amplitude * np.exp(-((wavenumber - center) / width)**2)
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        # Fit with Gaussian
        fit_result = ftir_analyzer.fit_peak(
            wavenumber_center=center,
            window=50,
            peak_shape=PeakShape.GAUSSIAN
        )
        
        assert 'parameters' in fit_result
        assert abs(fit_result['parameters']['center'] - center) < 2
        assert fit_result['r_squared'] > 0.95
    
    def test_material_identification(self, ftir_analyzer, polymer_ftir_spectrum):
        """Test spectral library matching"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        # Create reference library
        reference_spectra = {
            'polystyrene': transmittance + np.random.normal(0, 1, len(transmittance)),
            'polyethylene': np.ones_like(transmittance) * 90,
            'nylon': np.ones_like(transmittance) * 85
        }
        
        matches = ftir_analyzer.identify_material(
            reference_spectra=reference_spectra,
            correlation_threshold=0.9
        )
        
        assert len(matches) > 0
        assert matches[0]['material'] == 'polystyrene'
        assert matches[0]['correlation'] > 0.95

# ============================================================================
# Quality Control Tests
# ============================================================================

class TestSpectroscopyQC:
    """Test quality control module"""
    
    def test_signal_to_noise_calculation(self):
        """Test S/N ratio calculation"""
        # Create spectrum with known S/N
        signal = 100
        noise = 1
        spectrum = np.ones(1000) * signal
        spectrum[-100:] += np.random.normal(0, noise, 100)
        
        snr = SpectroscopyQC.check_signal_to_noise(spectrum, baseline_region=(900, 1000))
        
        assert snr > 50  # Should be approximately 100
    
    def test_saturation_detection(self):
        """Test detector saturation check"""
        # Create saturated spectrum
        spectrum = np.ones(100) * 0.5
        spectrum[40:60] = 0.98  # Saturated region
        
        result = SpectroscopyQC.check_saturation(spectrum, threshold=0.95)
        
        assert result['is_saturated'] == True
        assert result['saturated_points'] == 20
        assert abs(result['saturation_percentage'] - 20.0) < 0.1
    
    def test_spectral_range_check(self):
        """Test spectral range validation"""
        wavelength = np.linspace(300, 800, 100)
        expected_range = (200, 900)
        
        result = SpectroscopyQC.check_spectral_range(wavelength, expected_range)
        
        assert result['range_ok'] == True
        assert result['actual_range'] == (300, 800)
        assert abs(result['coverage_percentage'] - 500/700*100) < 0.1
    
    def test_measurement_validation(self):
        """Test comprehensive measurement validation"""
        # Valid spectrum
        valid_data = {
            'wavelength': np.linspace(200, 1000, 100),
            'intensity': np.random.random(100),
            'spectrum_type': 'transmission'
        }
        
        result = SpectroscopyQC.validate_measurement(valid_data)
        assert result['valid'] == True
        assert len(result['errors']) == 0
        
        # Invalid spectrum (missing field)
        invalid_data = {
            'wavelength': np.linspace(200, 1000, 100),
            'intensity': np.random.random(100)
        }
        
        result = SpectroscopyQC.validate_measurement(invalid_data)
        assert result['valid'] == False
        assert len(result['errors']) > 0
        
        # Spectrum with warnings (negative values)
        warning_data = {
            'wavelength': np.linspace(200, 1000, 100),
            'intensity': np.random.random(100) - 0.1,
            'spectrum_type': 'transmission'
        }
        
        result = SpectroscopyQC.validate_measurement(warning_data)
        assert len(result['warnings']) > 0

# ============================================================================
# Integration Tests
# ============================================================================

class TestIntegrationPipelines:
    """Test complete processing pipelines"""
    
    def test_uv_vis_complete_pipeline(self, silicon_spectrum):
        """Test complete UV-Vis processing pipeline"""
        wavelength, transmittance = silicon_spectrum
        
        results = process_uv_vis_measurement(
            wavelength=wavelength,
            intensity=transmittance,
            spectrum_type='transmission',
            calculate_band_gap=True,
            band_gap_type='indirect_allowed',
            baseline_correction=True
        )
        
        assert 'spectrum' in results
        assert 'peaks' in results
        assert 'band_gap' in results
        assert 'quality_metrics' in results
        
        # Check data integrity
        assert len(results['spectrum']['wavelength']) == len(wavelength)
        assert results['quality_metrics']['signal_to_noise'] > 10
    
    def test_ftir_complete_pipeline(self, polymer_ftir_spectrum):
        """Test complete FTIR processing pipeline"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        results = process_ftir_measurement(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type='transmittance',
            baseline_correction=True,
            identify_functional_groups=True
        )
        
        assert 'spectrum' in results
        assert 'peaks' in results
        assert 'quality_metrics' in results
        
        # Check peak identification
        assert len(results['peaks']) > 0
        for peak in results['peaks']:
            assert 'possible_groups' in peak

# ============================================================================
# Performance Tests
# ============================================================================

class TestPerformance:
    """Performance benchmarks for optical analysis"""
    
    @pytest.mark.performance
    def test_uv_vis_processing_speed(self, silicon_spectrum):
        """Benchmark UV-Vis processing speed"""
        wavelength, transmittance = silicon_spectrum
        analyzer = UVVisNIRAnalyzer()
        
        start_time = time.time()
        
        analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        analyzer.correct_baseline(BaselineMethod.ASYMMETRIC_LEAST_SQUARES)
        analyzer.detect_peaks()
        analyzer.calculate_band_gap(BandGapType.INDIRECT_ALLOWED)
        
        processing_time = time.time() - start_time
        
        assert processing_time < 2.0  # Should complete in under 2 seconds
        print(f"UV-Vis processing time: {processing_time:.3f} seconds")
    
    @pytest.mark.performance
    def test_ftir_processing_speed(self, polymer_ftir_spectrum):
        """Benchmark FTIR processing speed"""
        wavenumber, transmittance = polymer_ftir_spectrum
        analyzer = FTIRAnalyzer()
        
        start_time = time.time()
        
        analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        analyzer.correct_baseline(BaselineMethod.ASYMMETRIC_LEAST_SQUARES)
        analyzer.detect_peaks()
        
        processing_time = time.time() - start_time
        
        assert processing_time < 3.0  # Should complete in under 3 seconds
        print(f"FTIR processing time: {processing_time:.3f} seconds")
    
    @pytest.mark.performance
    def test_batch_processing_throughput(self):
        """Test batch processing throughput"""
        generator = OpticalTestDataGenerator()
        num_samples = 10
        
        start_time = time.time()
        
        for i in range(num_samples):
            wavelength, transmittance = generator.generate_uv_vis_spectrum('silicon')
            
            results = process_uv_vis_measurement(
                wavelength=wavelength,
                intensity=transmittance,
                spectrum_type='transmission',
                calculate_band_gap=True,
                baseline_correction=True
            )
        
        total_time = time.time() - start_time
        throughput = num_samples / total_time
        
        assert throughput > 1.0  # Should process at least 1 sample per second
        print(f"Batch processing throughput: {throughput:.2f} samples/second")

# ============================================================================
# Data Generator Tests
# ============================================================================

class TestDataGenerators:
    """Test synthetic data generators"""
    
    def test_uv_vis_data_generator(self):
        """Test UV-Vis test data generator"""
        generator = OpticalTestDataGenerator()
        
        # Test different material types
        materials = ['silicon', 'gaas', 'thin_film']
        
        for material in materials:
            wavelength, transmittance = generator.generate_uv_vis_spectrum(
                material_type=material,
                noise_level=0.01
            )
            
            assert len(wavelength) == len(transmittance)
            assert np.all(transmittance >= 0) and np.all(transmittance <= 1)
            assert np.all(np.diff(wavelength) > 0)  # Monotonic
    
    def test_ftir_data_generator(self):
        """Test FTIR test data generator"""
        generator = OpticalTestDataGenerator()
        
        # Test different material types
        materials = ['polymer', 'protein', 'silicon_oxide']
        
        for material in materials:
            wavenumber, transmittance = generator.generate_ftir_spectrum(
                material_type=material,
                noise_level=0.005
            )
            
            assert len(wavenumber) == len(transmittance)
            assert np.all(transmittance >= 0) and np.all(transmittance <= 100)
            assert np.all(np.diff(wavenumber) > 0)  # Monotonic

# ============================================================================
# Error Handling Tests
# ============================================================================

class TestErrorHandling:
    """Test error handling and edge cases"""
    
    def test_empty_spectrum_handling(self, uv_vis_analyzer):
        """Test handling of empty or invalid spectra"""
        with pytest.raises(ValueError):
            uv_vis_analyzer.detect_peaks()  # No spectrum loaded
        
        with pytest.raises(ValueError):
            uv_vis_analyzer.calculate_band_gap()  # No spectrum loaded
    
    def test_invalid_parameter_handling(self, uv_vis_analyzer):
        """Test handling of invalid parameters"""
        wavelength = np.linspace(200, 1000, 100)
        intensity = np.random.random(100)
        
        uv_vis_analyzer.load_spectrum(
            wavelength=wavelength,
            intensity=intensity,
            spectrum_type=SpectrumType.TRANSMISSION
        )
        
        # Invalid baseline method should fall back to default
        corrected = uv_vis_analyzer.correct_baseline(
            method=BaselineMethod.POLYNOMIAL,
            order=100  # Too high order
        )
        assert corrected is not None
    
    def test_numerical_stability(self, ftir_analyzer):
        """Test numerical stability with edge cases"""
        # Spectrum with zero values
        wavenumber = np.linspace(400, 4000, 100)
        transmittance = np.ones(100) * 100
        transmittance[40:60] = 0  # Zero transmittance region
        
        ftir_analyzer.load_spectrum(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type=SpectrumType.TRANSMITTANCE
        )
        
        # Should handle zero values in log calculation
        absorbance = ftir_analyzer.convert_to_absorbance()
        assert not np.any(np.isnan(absorbance))
        assert not np.any(np.isinf(absorbance))

# ============================================================================
# API Contract Tests
# ============================================================================

class TestAPIContract:
    """Test API response format and contracts"""
    
    def test_uv_vis_api_response_format(self, silicon_spectrum):
        """Test UV-Vis API response structure"""
        wavelength, transmittance = silicon_spectrum
        
        results = process_uv_vis_measurement(
            wavelength=wavelength,
            intensity=transmittance,
            spectrum_type='transmission'
        )
        
        # Check required fields
        required_fields = ['spectrum', 'peaks', 'quality_metrics']
        for field in required_fields:
            assert field in results
        
        # Check spectrum structure
        spectrum_fields = ['wavelength', 'intensity', 'energy_ev', 'wavenumber']
        for field in spectrum_fields:
            assert field in results['spectrum']
        
        # Check peak structure
        if results['peaks']:
            peak = results['peaks'][0]
            assert 'wavelength' in peak
            assert 'intensity' in peak
            assert 'prominence' in peak
    
    def test_ftir_api_response_format(self, polymer_ftir_spectrum):
        """Test FTIR API response structure"""
        wavenumber, transmittance = polymer_ftir_spectrum
        
        results = process_ftir_measurement(
            wavenumber=wavenumber,
            intensity=transmittance,
            spectrum_type='transmittance'
        )
        
        # Check required fields
        required_fields = ['spectrum', 'peaks', 'quality_metrics']
        for field in required_fields:
            assert field in results
        
        # Check spectrum structure
        spectrum_fields = ['wavenumber', 'intensity', 'absorbance']
        for field in spectrum_fields:
            assert field in results['spectrum']

# ============================================================================
# Run tests
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
    
    # Run performance tests separately
    print("\n" + "="*50)
    print("Running Performance Benchmarks")
    print("="*50)
    pytest.main([__file__, "-v", "-m", "performance"])
